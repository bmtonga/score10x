<?php 
	 require_once __DIR__ . '/config/dz.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
		<!-- PAGE TITLE HERE -->
		 <title><?php echo $DexignZoneSettings['site_level']['site_title'] ?></title>
		 <?php include 'elements/meta.php';?>
		 <!-- FAVICONS ICON -->
		 <link rel="shortcut icon" type="image/png" href="<?php echo $DexignZoneSettings['site_level']['favicon']?>">
		 
		 <?php include 'elements/page-css.php'; ?>
	 </head>
<body>

    <!--*******************
        Preloader start
    ********************-->
	<?php include 'elements/pre-loader.php'; ?>
    <!--*******************
        Preloader end
    ********************-->
    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper" class="wallet-open active">
	
        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include 'elements/nav-header.php'; ?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Chat box start
        ***********************************-->
		<?php include 'elements/chatbox.php'; ?>
		<!--**********************************
            Chat box End
        ***********************************-->
		<!--**********************************
            Header start
        ***********************************-->
		<?php include 'elements/header.php'; ?>
			<!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include 'elements/sidebar.php'; ?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--****
		Wallet Sidebar
		****-->
		<div class="wallet-bar wow fadeInRight dlab-scroll active" id="wallet-bar" data-wow-delay="0.7s">		
			<div class="row ">
				<!--column-->
				<div class="col-xl-12">
					<div class="card bg-transparent mb-1">
						<div class="card-header border-0 px-3">
							<div>
								<h2 class="heading mb-0">Recent Students</h2>
								<span>You have <span class="font-w600">456</span> Students</span>
							</div>
							<div >
								<a href="#" class="add icon-box bg-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
									<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M5.188 13.412V8.512H0.428V5.348H5.188V0.531999H8.352V5.348H13.14V8.512H8.352V13.412H5.188Z" fill="white"/>
									</svg>
								</a>									
							</div>	
						</div>
						<div class="card-body height450 dlab-scroll loadmore-content recent-activity-wrapper p-3 pt-2" id="RecentActivityContent">
							<!--student-->
							<div class="d-flex align-items-center student">
								<span class="dz-media">
									<img src="assets/images/profile/small/pic1.jpg" alt="" width="50" class="avatar">
								</span>
								<div class="user-info">
									<h6 class="name"><a href="app-profile.php">Samantha William</a></h6>
									<span class="fs-14 font-w400 text-wrap">Class VII A</span>
								</div>
								<div class="icon-box st-box ms-auto">
									<a href="#">
										<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"/>
										</svg>
									</a>		
								</div>													
							</div>
							<!--/student-->
							<!--student-->
							<div class="d-flex align-items-center student">
								<span class="dz-media">
									<img src="assets/images/profile/small/pic2.jpg" alt="" width="50" class="avatar">
								</span>
								<div class="user-info">
									<h6 class="name"><a href="app-profile.php">Tony Soap</a></h6>
									<span class=" text-wrap text-break">Class VII B</span>
								</div>
								<div class="icon-box st-box ms-auto">
									<a href="#">
										<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"/>
										</svg>
									</a>		
								</div>																				
							</div>
							<!--/student-->
							<!--student-->
							<div class="d-flex align-items-center student">
								<span class="dz-media">
									<img src="assets/images/profile/small/pic3.jpg" alt="" class="avatar">
								</span>
								<div class="user-info">
									<h6 class="name"><a href="app-profile.php">Karen Hope</a></h6>
									<span>Web Developer</span>
								</div>
								<div class="icon-box st-box ms-auto">
									<a href="#">
										<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"/>
										</svg>
									</a>		
								</div>																			
							</div>
							<!--/student-->
							<!--student-->
							<div class="d-flex align-items-center student">
								<span class="dz-media">
									<img src="assets/images/profile/small/pic4.jpg" alt="" class="avatar">
								</span>
								<div class="user-info">
									<h6 class="name"><a href="app-profile.php">Jordan Nico</a></h6>
									<span class=" text-wrap">Class VII A</span>
								</div>
								<div class="icon-box st-box ms-auto">
									<a href="#">
										<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"/>
										</svg>
									</a>		
								</div>																				
							</div>
							<!--/student-->
							<!--student-->
							<div class="d-flex align-items-center student">
								<span class="dz-media">
									<img src="assets/images/profile/small/pic5.jpg" alt="" class="avatar">
								</span>
								<div class="user-info">
									<h6 class="name"><a href="app-profile.php">Nadila Adja</a></h6>
									<span class=" text-wrap">Class VII B</span>
								</div>
								<div class="icon-box st-box ms-auto">
									<a href="#">
										<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"/>
										</svg>
									</a>		
								</div>																				
							</div>
							<!--/student-->
						</div>
						<div class="card-footer text-center border-0 pt-0 px-3 pb-0">
							<a href="javascript:void(0);" class="btn btn-block btn-primary light btn-rounded dlab-load-more" id="RecentActivity" rel="assets/ajax/recentactivity.html">View More</a>
						</div>
					</div>
				</div>
				<!--/column-->
				<!--column-->
				<div class="col-xl-12">
					<div class="card massage bg-transparent mb-0">
						<div class="card-header border-0 px-3 py-0">
							<div>
								<h2 class="heading">Messages</h2>
							</div>
							
						</div>
						<div class="card-body height450 dlab-scroll p-0 px-3" id="messageContent">
							<!--student-->
							<div class="d-flex student border-bottom">
								<div class="d-flex align-items-center">
									<span class="dz-media">
										<img src="assets/images/profile/small/pic1.jpg" alt="" class="avatar">
									</span>
									<div class="user-info">
										<h6 class="name"><a href="app-profile.php">Samantha William</a></h6>
										<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
									</div>
								</div>													
								<div class="indox">
									<span class="fs-14 font-w400 text-wrap">12:45 PM</span>		
								</div>
							</div>
							<!--student-->
							<div class="d-flex student border-bottom">
								<div class="d-flex align-items-center">
									<span class="dz-media">
										<img src="assets/images/profile/small/pic2.jpg" alt="" class="avatar">
									</span>
									<div class="user-info">
										<h6 class="name"><a href="app-profile.php">Tony Soap</a></h6>
										<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
									</div>
								</div>													
								<div class="indox">
									<span class="fs-14 font-w400 text-wrap">12:45 PM</span>		
								</div>
							</div>
							<!--student-->
							<div class="d-flex student border-bottom">
								<div class="d-flex align-items-center">
									<span class="dz-media">
										<img src="assets/images/profile/small/pic2.jpg" alt="" class="avatar">
									</span>
									<div class="user-info">
										<h6 class="name"><a href="app-profile.php">Tony Soap</a></h6>
										<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
									</div>
								</div>													
								<div class="indox">
									<span class="fs-14 font-w400 text-wrap">12:45 PM</span>		
								</div>
							</div>
							<!--tudent-->
							<div class="d-flex student border-bottom">
								<div class="d-flex align-items-center">
									<span class="dz-media">
										<img src="assets/images/profile/small/pic3.jpg" alt="" class="avatar">
									</span>
									<div class="user-info">
										<h6 class="name"><a href="app-profile.php">Jordan Nico</a></h6>
										<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
									</div>
								</div>													
								<div class="indox">
									<span class="fs-14 font-w400 text-wrap">12:45 PM</span>		
								</div>
							</div>
							<!--student-->
							<div class="d-flex student border-bottom">
								<div class="d-flex align-items-center">
									<span class="dz-media">
										<img src="assets/images/profile/small/pic4.jpg" alt="" class="avatar">
									</span>
									<div class="user-info">
										<h6 class="name"><a href="app-profile.php">Nadila Adja</a></h6>
										<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
									</div>
								</div>													
								<div class="indox">
									<span class="fs-14 font-w400 text-wrap">12:45 PM</span>		
								</div>
							</div>
							<div class="d-flex student border-bottom">
								<div class="d-flex align-items-center">
									<span class="dz-media">
										<img src="assets/images/profile/small/pic4.jpg" alt="" class="avatar">
									</span>
									<div class="user-info">
										<h6 class="name"><a href="app-profile.php">Nadila Adja</a></h6>
										<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
									</div>
								</div>													
								<div class="indox">
									<span class="fs-14 font-w400 text-wrap">12:45 PM</span>		
								</div>
							</div>
						</div>
						<div class="card-footer text-center border-0 px-3 pb-0">
							<a href="contact.php" class="btn btn-block btn-primary light btn-rounded dlab-load-more" id="message" rel="assets/ajax/message-content.php">View More</a>
						</div>
					</div>
				</div>
				<!--/column-->
				<!--column-->
				<div class="col-xl-12 ">
					<div class="card tags bg-transparent mb-0">
						<div class="card-header border-0 px-3 py-0">
							<h2 class="heading">Current Foods Menu</h2>
						</div>
						<div class="card-body  p-3 py-1 ">	
							<div class="card-body-inner food">
								<span class="dz-media">
									<img src="assets/images/food/pic1.jpg" alt="" class="avatar">
								</span>
								<div class="user-info">
									<h5 class="name"><a href="app-profile.php">Beef Steak with Fried Potato</a></h5>
									<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
								</div>
							</div>	
							<div class="card-body-inner food">
								<span class="dz-media">
									<img src="assets/images/food/pic2.jpg" alt="" class="avatar">
								</span>
								<div class="user-info">
									<h5 class="name"><a href="app-profile.php">Pancake with Honey</a></h5>
									<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
								</div>
							</div>	
							<div class="card-body-inner food">
								<span class="dz-media">
									<img src="assets/images/food/pic3.jpg" alt="" class="avatar">
								</span>
								<div class="user-info">
									<h5 class="name"><a href="app-profile.php">Japanese Beef Ramen</a></h5>
									<span class="fs-14 font-w400 text-wrap">Lorem ipsum dolor sit</span>
								</div>
							</div>
						</div>
						<div class="card-footer pt-0 border-0 px-2">
							<button class="btn btn-block btn-primary light btn-rounded  mb-3">View More</button>		
						</div>
					</div>	
							
				</div>
				<!--column-->
			</div>
		</div>
		<div class="wallet-bar-close"></div>
		<!--**********************************
            Content body start
        ***********************************-->
        <!--**********************************
            Content body start
        ***********************************-->
		<div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<!-- Row -->
				<div class="row">
					<div class="col-xl-12">
						<div class="card">
							<div class="card-body pb-xl-4 pb-sm-3 pb-0">	
								<div class="row">
									<div class="col-xl-3 col-6">
										<div class="content-box">
											<div class="icon-box icon-box-xl std-data">
												<svg width="25" height="25" viewBox="0 0 30 38" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path fill-rule="evenodd" clip-rule="evenodd" d="M12.9288 37.75H3.75C1.67875 37.75 0 36.0713 0 34V23.5863C0 21.7738 1.29625 20.2213 3.07875 19.8975C5.72125 19.4163 10.2775 18.5875 12.855 18.12C14.2737 17.8612 15.7263 17.8612 17.145 18.12C19.7225 18.5875 24.2788 19.4163 26.9213 19.8975C28.7038 20.2213 30 21.7738 30 23.5863C30 26.3125 30 31.0825 30 34C30 36.0713 28.3212 37.75 26.25 37.75H12.9288ZM24.785 22.05L24.79 22.0563C25.0088 22.3838 25.06 22.795 24.9287 23.1662L24.0462 25.6662C23.9312 25.9925 23.685 26.2575 23.3675 26.3963L21.7075 27.12L22.3675 28.4412C22.5525 28.81 22.5425 29.2462 22.3425 29.6075L19.2075 35.25H26.25C26.94 35.25 27.5 34.69 27.5 34C27.5 31.0825 27.5 26.3125 27.5 23.5863C27.5 22.9825 27.0675 22.465 26.4738 22.3562L24.785 22.05ZM21.3663 21.4275L16.6975 20.5788C15.575 20.375 14.425 20.375 13.3025 20.5788L8.63375 21.4275L7.63625 22.9238L8.13 24.3213L10.5 25.3537C10.8138 25.4912 11.0575 25.7512 11.175 26.0737C11.2925 26.3962 11.2712 26.7525 11.1175 27.0588L10.1625 28.9688L13.6525 35.25H16.3475L19.8375 28.9688L18.8825 27.0588C18.7288 26.7525 18.7075 26.3962 18.825 26.0737C18.9425 25.7512 19.1862 25.4912 19.5 25.3537L21.87 24.3213L22.3638 22.9238L21.3663 21.4275ZM5.215 22.05L3.52625 22.3562C2.9325 22.465 2.5 22.9825 2.5 23.5863V34C2.5 34.69 3.06 35.25 3.75 35.25H10.7925L7.6575 29.6075C7.4575 29.2462 7.4475 28.81 7.6325 28.4412L8.2925 27.12L6.6325 26.3963C6.315 26.2575 6.06875 25.9925 5.95375 25.6662L5.07125 23.1662C4.94 22.795 4.99125 22.3838 5.21 22.0563L5.215 22.05ZM23.75 29V31.5C23.75 32.19 24.31 32.75 25 32.75C25.69 32.75 26.25 32.19 26.25 31.5V29C26.25 28.31 25.69 27.75 25 27.75C24.31 27.75 23.75 28.31 23.75 29ZM15 0.25C10.5163 0.25 6.875 3.89125 6.875 8.375C6.875 12.8587 10.5163 16.5 15 16.5C19.4837 16.5 23.125 12.8587 23.125 8.375C23.125 3.89125 19.4837 0.25 15 0.25ZM15 2.75C18.105 2.75 20.625 5.27 20.625 8.375C20.625 11.48 18.105 14 15 14C11.895 14 9.375 11.48 9.375 8.375C9.375 5.27 11.895 2.75 15 2.75Z" fill="white"/>
												</svg>
											</div>
											<div  class="chart-num">
												<p>Students</p>
												<h2 class="font-w700 mb-0">932</h2>
											</div>
										</div>
									</div>
									<div class="col-xl-3 col-6">
										<div class="content-box">
											<div class="teach-data icon-box icon-box-xl">
												<svg width="25" height="25" viewBox="0 0 30 38" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path fill-rule="evenodd" clip-rule="evenodd" d="M0 34C0 36.0713 1.67875 37.75 3.75 37.75H26.25C28.3212 37.75 30 36.0713 30 34C30 31.0825 30 26.3125 30 23.5863C30 21.7738 28.7038 20.2213 26.9213 19.8975C24.2788 19.4163 19.7225 18.5875 17.145 18.12C15.7263 17.8612 14.2737 17.8612 12.855 18.12C10.2775 18.5875 5.72125 19.4163 3.07875 19.8975C1.29625 20.2213 0 21.7738 0 23.5863V34ZM17.885 20.795L19.7612 27.9288C20.0075 28.865 19.6775 29.8588 18.92 30.4638C18.28 30.9738 17.2713 31.7788 16.5713 32.3388C15.6525 33.0713 14.3475 33.0713 13.4287 32.3388C12.7287 31.7788 11.72 30.9738 11.08 30.4638C10.3225 29.8588 9.9925 28.865 10.2388 27.9288L12.115 20.795L3.52625 22.3562C2.9325 22.465 2.5 22.9825 2.5 23.5863V34C2.5 34.69 3.06 35.25 3.75 35.25C8.98 35.25 21.02 35.25 26.25 35.25C26.94 35.25 27.5 34.69 27.5 34C27.5 31.0825 27.5 26.3125 27.5 23.5863C27.5 22.9825 27.0675 22.465 26.4738 22.3562L17.885 20.795ZM15.2038 20.4288C15.0675 20.425 14.9325 20.425 14.7962 20.4288L12.6663 28.5312L14.9887 30.3837C14.995 30.39 15.005 30.39 15.0113 30.3837L17.3337 28.5312L15.2038 20.4288ZM15 0.25C10.5163 0.25 6.875 3.89125 6.875 8.375C6.875 12.8587 10.5163 16.5 15 16.5C19.4837 16.5 23.125 12.8587 23.125 8.375C23.125 3.89125 19.4837 0.25 15 0.25ZM15 2.75C18.105 2.75 20.625 5.27 20.625 8.375C20.625 11.48 18.105 14 15 14C11.895 14 9.375 11.48 9.375 8.375C9.375 5.27 11.895 2.75 15 2.75Z" fill="white"/>
												</svg>
											</div>
											<div class="chart-num">
												<p>Teachers</p>
												<h2 class="font-w700 mb-0">754</h2>
											</div>
										</div>
									</div>
									<div class="col-xl-3 col-6">
										<div class="content-box">
											<div class="event-data icon-box icon-box-xl">
												<svg width="20" height="20" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M24 2.75H21.5V1.5C21.5 1.16848 21.3683 0.850537 21.1339 0.616117C20.8995 0.381696 20.5815 0.25 20.25 0.25C19.9185 0.25 19.6005 0.381696 19.3661 0.616117C19.1317 0.850537 19 1.16848 19 1.5V2.75H15.25V1.5C15.25 1.16848 15.1183 0.850537 14.8839 0.616117C14.6495 0.381696 14.3315 0.25 14 0.25C13.6685 0.25 13.3505 0.381696 13.1161 0.616117C12.8817 0.850537 12.75 1.16848 12.75 1.5V2.75H9V1.5C9 1.16848 8.8683 0.850537 8.63388 0.616117C8.39946 0.381696 8.08152 0.25 7.75 0.25C7.41848 0.25 7.10054 0.381696 6.86612 0.616117C6.6317 0.850537 6.5 1.16848 6.5 1.5V2.75H4C3.00544 2.75 2.05161 3.14509 1.34835 3.84835C0.645088 4.55161 0.25 5.50544 0.25 6.5V24C0.25 24.9946 0.645088 25.9484 1.34835 26.6517C2.05161 27.3549 3.00544 27.75 4 27.75H24C24.9946 27.75 25.9484 27.3549 26.6517 26.6517C27.3549 25.9484 27.75 24.9946 27.75 24V6.5C27.75 5.50544 27.3549 4.55161 26.6517 3.84835C25.9484 3.14509 24.9946 2.75 24 2.75ZM2.75 6.5C2.75 6.16848 2.8817 5.85054 3.11612 5.61612C3.35054 5.3817 3.66848 5.25 4 5.25H6.5V6.5C6.5 6.83152 6.6317 7.14946 6.86612 7.38388C7.10054 7.6183 7.41848 7.75 7.75 7.75C8.08152 7.75 8.39946 7.6183 8.63388 7.38388C8.8683 7.14946 9 6.83152 9 6.5V5.25H12.75V6.5C12.75 6.83152 12.8817 7.14946 13.1161 7.38388C13.3505 7.6183 13.6685 7.75 14 7.75C14.3315 7.75 14.6495 7.6183 14.8839 7.38388C15.1183 7.14946 15.25 6.83152 15.25 6.5V5.25H19V6.5C19 6.83152 19.1317 7.14946 19.3661 7.38388C19.6005 7.6183 19.9185 7.75 20.25 7.75C20.5815 7.75 20.8995 7.6183 21.1339 7.38388C21.3683 7.14946 21.5 6.83152 21.5 6.5V5.25H24C24.3315 5.25 24.6495 5.3817 24.8839 5.61612C25.1183 5.85054 25.25 6.16848 25.25 6.5V10.25H2.75V6.5ZM25.25 24C25.25 24.3315 25.1183 24.6495 24.8839 24.8839C24.6495 25.1183 24.3315 25.25 24 25.25H4C3.66848 25.25 3.35054 25.1183 3.11612 24.8839C2.8817 24.6495 2.75 24.3315 2.75 24V12.75H25.25V24Z" fill="white"/>
												</svg>	
											</div>
											<div class="chart-num">
												<p>Events</p>
												<h2 class="font-w700 mb-0">40</h2>
											</div>
										</div>
									</div>
									<div class="col-xl-3 col-6">
										<div class="content-box">
											<div class="food-data icon-box icon-box-xl bg-dark">
												<svg width="23" height="23" viewBox="0 0 28 34" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M8.25448 0.509167C5.96882 1.64226 4.0464 3.39315 2.70524 5.56327C1.36408 7.7334 0.657848 10.2359 0.666646 12.787V18.7167C0.667705 19.5871 1.01397 20.4216 1.62948 21.0372C2.245 21.6527 3.07951 21.9989 3.94998 22H7.33331V32C7.33331 32.442 7.50891 32.866 7.82147 33.1785C8.13403 33.4911 8.55795 33.6667 8.99998 33.6667C9.44201 33.6667 9.86593 33.4911 10.1785 33.1785C10.4911 32.866 10.6666 32.442 10.6666 32V2C10.6664 1.71598 10.5936 1.43673 10.4552 1.18872C10.3168 0.940703 10.1173 0.732152 9.87574 0.582831C9.63414 0.43351 9.3584 0.348368 9.07467 0.335477C8.79095 0.322585 8.50863 0.382371 8.25448 0.509167ZM7.33331 18.6833L3.99998 18.7167V12.787C3.99498 11.3525 4.28878 9.93273 4.86268 8.61805C5.43658 7.30336 6.27798 6.12261 7.33331 5.151V18.6833ZM24 2V8.66667C23.9994 9.10852 23.8236 9.53211 23.5112 9.84455C23.1988 10.157 22.7752 10.3328 22.3333 10.3333V2C22.3333 1.55797 22.1577 1.13405 21.8452 0.821489C21.5326 0.508929 21.1087 0.333334 20.6666 0.333334C20.2246 0.333334 19.8007 0.508929 19.4881 0.821489C19.1756 1.13405 19 1.55797 19 2V10.3333C18.5581 10.3328 18.1345 10.157 17.8221 9.84455C17.5097 9.53211 17.3339 9.10852 17.3333 8.66667V2C17.3333 1.55797 17.1577 1.13405 16.8452 0.821489C16.5326 0.508929 16.1087 0.333334 15.6666 0.333334C15.2246 0.333334 14.8007 0.508929 14.4881 0.821489C14.1756 1.13405 14 1.55797 14 2V8.66667C14.0014 9.9923 14.5287 11.2632 15.4661 12.2006C16.4034 13.138 17.6743 13.6652 19 13.6667V32C19 32.442 19.1756 32.866 19.4881 33.1785C19.8007 33.4911 20.2246 33.6667 20.6666 33.6667C21.1087 33.6667 21.5326 33.4911 21.8452 33.1785C22.1577 32.866 22.3333 32.442 22.3333 32V13.6667C23.6589 13.6652 24.9299 13.138 25.8672 12.2006C26.8046 11.2632 27.3319 9.9923 27.3333 8.66667V2C27.3333 1.55797 27.1577 1.13405 26.8452 0.821489C26.5326 0.508929 26.1087 0.333334 25.6666 0.333334C25.2246 0.333334 24.8007 0.508929 24.4881 0.821489C24.1756 1.13405 24 1.55797 24 2Z" fill="white"/>
												</svg>
											</div>
											<div class="chart-num">
												<p>Foods</p>
												<h2 class="font-w700 mb-0">32k</h2>
											</div>
										</div>
									</div>
								</div>	
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xl-6 ">
						<div class="card crypto-chart ">
							<div class="card-header pb-0 border-0 flex-wrap">
								<div class="mb-2 mb-sm-0">
									<div class="chart-title mb-3">
										<h2 class="heading">School Performance</h2>	
									</div>
								</div>
								<div class="p-static">
									<div class="d-flex align-items-center mb-3 mb-sm-0">
										<div class="round weekly" id="dzOldSeries">
											<div>
												<input type="checkbox" id="checkbox1" name="radio" value="weekly">
												<label for="checkbox1" class="checkmark"></label>
											</div>
											<div>
												<span class="fs-14">This Week</span>
												<h4 class="fs-5 font-w700 mb-0">1.245</h4>
											</div>
										</div>
										<div class="round" id="dzNewSeries">
											<div>
												<input type="checkbox" id="checkbox" name="radio" value="monthly">
												<label for="checkbox" class="checkmark"></label>
											</div>
											<div>
												<span class="fs-14">Last Week</span>
												<h4 class="fs-5 font-w700 mb-0">1.356</h4>
											</div>	
										</div>
									</div>
								</div>
							</div>
							<div class="card-body pt-2 custome-tooltip pb-0 px-2">
								<div id="marketChart"></div>
							</div>
						</div>
					</div>
					<div class="col-xl-6">
						<div class="card h-auto">
							<div class="card-header border-0 pb-0 flex-wrap">
								<h4 class="heading mb-3 mb-sm-0">School Overview</h4>
								<ul class="nav nav-pills mix-chart-tab" id="pills-tab" role="tablist">
								  <li class="nav-item" role="presentation">
									<button class="nav-link active" data-series="week" id="pills-week-tab" data-bs-toggle="pill" data-bs-target="#pills-week" type="button" role="tab"  aria-selected="true">Week</button>
								  </li>
								  <li class="nav-item" role="presentation">
									<button class="nav-link" data-series="month" id="pills-month-tab" data-bs-toggle="pill" data-bs-target="#pills-month" type="button" role="tab"  aria-selected="false">Month</button>
								  </li>
								  <li class="nav-item" role="presentation">
									<button class="nav-link" data-series="year" id="pills-year-tab" data-bs-toggle="pill" data-bs-target="#pills-year" type="button" role="tab"  aria-selected="false">Year</button>
								  </li>
								   <li class="nav-item" role="presentation">
									<button class="nav-link" data-series="all" id="pills-all-tab" data-bs-toggle="pill" data-bs-target="#pills-all" type="button" role="tab" aria-selected="false">All</button>
								  </li>
								</ul>
							</div>
							<div class="card-body  p-0">
								<div id="overiewChart"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xl-4 wow fadeInUp" data-wow-delay="1.5s">
						<div class="card">
							<div class="card-header pb-0 border-0 flex-wrap">
								<div>
									<div class="mb-3">
										<h2 class="heading mb-0">School Calendar</h2>	
									</div>
								</div>
							</div>
							<div class="card-body text-center event-calender  py-0 px-1">
								<input type='text' class="form-control d-none" id='datetimepicker1'>
							</div>
						</div>
					</div>
					<!--column-->
					<div class="col-xl-8">
						<div class="card">
							<div class="card-header py-3 border-0 px-3">
								<h4 class="heading m-0">Teacher Deatails</h4>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive basic-tbl">
									<table id="teacher-table" class="tech-data" style="min-width: 798px">
										<thead>
											<tr>
												<th>Name</th>
												<th>Subject</th>
												<th>Qulification</th>
												<th>Fees</th>
												<th class="text-end">Performance</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>Yatin Xarma</td>
												<td>Programming</td>
												<td>B.Tech</td>
												<td>$ 217.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-danger">Bad</span></td>
											</tr>
											<tr>
												<td>Ramen</td>
												<td>Basic Art</td>
												<td>BA</td>
												<td>$ 218.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Harry</td>
												<td>English</td>
												<td>B.Tech</td>
												<td>$ 219.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Hanu</td>
												<td>Programing</td>
												<td>B.Tech</td>
												<td>$ 217.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Jorge</td>
												<td>History</td>
												<td>BA</td>
												<td>$ 212.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>James</td>
												<td>History</td>
												<td>B.Com</td>
												<td>$ 21.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-danger">Bad</span></td>
											</tr>
											<tr>
												<td>Vicky canady</td>
												<td>Basic Art</td>
												<td>B.Tech</td>
												<td>$ 217.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Jack Xarma</td>
												<td>Programming</td>
												<td>B.Tech</td>
												<td>$ 19.2.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Ramon</td>
												<td>Basic Art</td>
												<td>BA</td>
												<td>$ 217.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Harry john</td>
												<td>History</td>
												<td>B.Tech</td>
												<td>$ 18.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Hardy</td>
												<td>Basic Algorithm</td>
												<td>B.E</td>
												<td>$ 17.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Jeo</td>
												<td>English</td>
												<td>BA</td>
												<td>$ 217.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>James Brown</td>
												<td>History</td>
												<td>B.Com</td>
												<td>$ 15.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-danger">Bad</span></td>
											</tr>
											<tr>
												<td>John</td>
												<td>Art</td>
												<td>B.Tech</td>
												<td>$ 217.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Janny</td>
												<td>Basic Algorithm</td>
												<td>B.Tech</td>
												<td>$ 21.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											<tr>
												<td>Jorge clek</td>
												<td>English</td>
												<td>BA</td>
												<td>$ 22.70</td>
												<td class="text-end"><span class="badge badge-sm light badge-success">Good</span></td>
											</tr>
											
											
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
					<!--/column-->
				</div>
				<!-- column-->
				<div class="col-xl-12">
					<div class="card">
						<div class="card-header border-0 p-3">
							<h4 class="heading mb-0">Unpaid Student Intuition</h4>
						</div>
						<div class="card-body p-0">
							<div class="table-responsive basic-tbl">
								<table id="example-1" class="display" style="min-width: 845px">
									<thead>
										<tr>
											<th>Name</th>
											<th>ID</th>
											<th>Class</th>
											<th>Fees</th>
											<th>Rank</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/1.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Samantha William</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 123456789</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII C</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 50,036</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400-6)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400-6">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
										</tr>
										<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/2.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Tony Soap</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 1234567810</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII A</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 51,038</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
										</tr>
										<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/3.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Jordan Nico</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 1234567811</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII B</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 52,036</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400-1">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
											</tr>
											<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/4.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Karen Hope</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 1234567812</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII A</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 53,036</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400-2)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400-2">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
										</tr>
										<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/5.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Nadila Adja</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 1234567813</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII B</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 54,036</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400-3)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400-3">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
										</tr>
										<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/1.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Samantha William</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 123456789</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII C</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 50,036</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400-6)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400-6">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
										</tr>
										<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/2.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Tony Soap</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 1234567810</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII A</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 51,038</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
										</tr>
										<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/3.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Jordan Nico</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 1234567811</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII B</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 52,036</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400-1">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
											</tr>
											<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/4.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Karen Hope</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 1234567812</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII A</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 53,036</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400-2)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400-2">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
										</tr>
										<tr>
											<td>
												<div class="trans-list">
													<img src="assets/images/trans/5.jpg" alt="" class="avatar avatar-sm me-3">
													<h4>Nadila Adja</h4>
												</div>
											</td>
											<td><span class="text-primary font-w600">ID 1234567813</span></td>
											<td>
												<div class="d-flex align-items-center">	
													<div class="icon-box icon-box-sm bg-secondary">
														<svg width="16" height="16" viewBox="0 0 18 24" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M12.7055 6.52503C12.7055 6.73128 12.6914 6.93753 12.6656 7.14144C12.6773 7.05941 12.689 6.97503 12.6984 6.893C12.6422 7.30081 12.5344 7.69691 12.3773 8.07659C12.4078 8.00159 12.4406 7.92659 12.4711 7.85159C12.314 8.22191 12.1125 8.56878 11.8664 8.88753C11.9156 8.82425 11.9648 8.76097 12.014 8.69769C11.7703 9.01175 11.4867 9.29534 11.1726 9.53909C11.2359 9.48987 11.2992 9.44066 11.3625 9.39144C11.0437 9.63519 10.6969 9.83909 10.3265 9.99612C10.4015 9.96566 10.4765 9.93284 10.5515 9.90237C10.1719 10.0594 9.77577 10.1672 9.36795 10.2235C9.44998 10.2117 9.53436 10.2 9.61639 10.1907C9.20623 10.2446 8.79373 10.2446 8.38358 10.1907C8.46561 10.2024 8.54998 10.2141 8.63201 10.2235C8.2242 10.1672 7.82811 10.0594 7.44842 9.90237C7.52342 9.93284 7.59842 9.96566 7.67342 9.99612C7.30311 9.83909 6.95623 9.63753 6.63748 9.39144C6.70076 9.44066 6.76404 9.48987 6.82732 9.53909C6.51326 9.29534 6.22967 9.01175 5.98592 8.69769C6.03514 8.76097 6.08436 8.82425 6.13357 8.88753C5.88982 8.56878 5.68592 8.22191 5.52889 7.85159C5.55936 7.92659 5.59217 8.00159 5.62264 8.07659C5.4656 7.69691 5.35779 7.30081 5.30154 6.893C5.31326 6.97503 5.32498 7.05941 5.33436 7.14144C5.28045 6.73128 5.28045 6.31878 5.33436 5.90863C5.32264 5.99066 5.31092 6.07503 5.30154 6.15706C5.35779 5.74925 5.4656 5.35316 5.62264 4.97347C5.59217 5.04847 5.55936 5.12347 5.52889 5.19847C5.68592 4.82816 5.88748 4.48128 6.13357 4.16253C6.08436 4.22581 6.03514 4.28909 5.98592 4.35238C6.22967 4.03831 6.51326 3.75472 6.82732 3.51097C6.76404 3.56019 6.70076 3.60941 6.63748 3.65863C6.95623 3.41488 7.30311 3.21097 7.67342 3.05394C7.59842 3.08441 7.52342 3.11722 7.44842 3.14769C7.82811 2.99066 8.2242 2.88284 8.63201 2.82659C8.54998 2.83831 8.46561 2.85003 8.38358 2.85941C8.79373 2.8055 9.20623 2.8055 9.61639 2.85941C9.53436 2.84769 9.44998 2.83597 9.36795 2.82659C9.77577 2.88284 10.1719 2.99066 10.5515 3.14769C10.4765 3.11722 10.4015 3.08441 10.3265 3.05394C10.6969 3.21097 11.0437 3.41253 11.3625 3.65863C11.2992 3.60941 11.2359 3.56019 11.1726 3.51097C11.4867 3.75472 11.7703 4.03831 12.014 4.35238C11.9648 4.28909 11.9156 4.22581 11.8664 4.16253C12.1101 4.48128 12.314 4.82816 12.4711 5.19847C12.4406 5.12347 12.4078 5.04847 12.3773 4.97347C12.5344 5.35316 12.6422 5.74925 12.6984 6.15706C12.6867 6.07503 12.675 5.99066 12.6656 5.90863C12.6914 6.11253 12.7031 6.31878 12.7055 6.52503C12.7078 7.01487 13.1344 7.48597 13.643 7.46253C14.1492 7.43909 14.5828 7.05003 14.5805 6.52503C14.5758 5.40238 14.2383 4.25394 13.5773 3.33988C13.3992 3.09378 13.2094 2.85238 12.9984 2.63441C12.7851 2.41409 12.5508 2.22425 12.307 2.03909C11.864 1.70159 11.3695 1.45316 10.8445 1.26097C8.72811 0.485188 6.17576 1.17659 4.74373 2.92034C4.54685 3.15941 4.35935 3.40784 4.19998 3.67503C4.0406 3.93988 3.91639 4.22113 3.80154 4.50706C3.58592 5.03675 3.47576 5.59925 3.43123 6.16878C3.34451 7.28441 3.63513 8.44925 4.21639 9.4055C4.77654 10.3289 5.62264 11.1211 6.6117 11.5688C6.90233 11.7 7.19998 11.8219 7.50936 11.9086C7.81639 11.993 8.12811 12.0399 8.44451 12.0774C9.02108 12.1453 9.60936 12.0985 10.1789 11.9836C12.3422 11.543 14.1539 9.67972 14.4891 7.493C14.5383 7.17425 14.5758 6.8555 14.5758 6.53206C14.5781 6.04222 14.1422 5.57113 13.6383 5.59456C13.132 5.61097 12.7055 6.00003 12.7055 6.52503ZM15.8156 21.1805C15.3562 21.1805 14.8969 21.1805 14.4375 21.1805C13.343 21.1805 12.2508 21.1805 11.1562 21.1805C9.83905 21.1805 8.52186 21.1805 7.20233 21.1805C6.06561 21.1805 4.92889 21.1805 3.78982 21.1805C3.25779 21.1805 2.72576 21.1852 2.19373 21.1805C2.13513 21.1805 2.07654 21.1758 2.02029 21.1688C2.10232 21.1805 2.1867 21.1922 2.26873 21.2016C2.17498 21.1875 2.08591 21.1617 1.9992 21.1266C2.0742 21.1571 2.1492 21.1899 2.2242 21.2203C2.13045 21.1805 2.04373 21.1289 1.9617 21.0657C2.02498 21.1149 2.08826 21.1641 2.15154 21.2133C2.08123 21.1547 2.0156 21.0914 1.95935 21.0211C2.00857 21.0844 2.05779 21.1477 2.10701 21.211C2.04373 21.1289 1.99451 21.0422 1.95232 20.9485C1.98279 21.0235 2.0156 21.0985 2.04607 21.1735C2.01091 21.0867 1.98748 20.9953 1.97107 20.9039C1.98279 20.986 1.99451 21.0703 2.00388 21.1524C1.96638 20.8688 1.99216 20.5688 1.99216 20.2828C1.99216 19.9477 1.99216 19.6149 1.99216 19.2797C1.99216 19.0289 2.00623 18.7805 2.03904 18.5321C2.02732 18.6141 2.0156 18.6985 2.00623 18.7805C2.07185 18.3 2.19841 17.8289 2.38826 17.3813C2.35779 17.4563 2.32498 17.5313 2.29451 17.6063C2.47732 17.1797 2.7117 16.7789 2.99529 16.411C2.94607 16.4742 2.89685 16.5375 2.84763 16.6008C3.13123 16.2375 3.45701 15.9094 3.82264 15.6258C3.75935 15.675 3.69607 15.7242 3.63279 15.7735C4.00076 15.4899 4.40154 15.2555 4.8281 15.0727C4.7531 15.1032 4.6781 15.136 4.6031 15.1664C5.05076 14.9789 5.51951 14.85 6.00232 14.7844C5.92029 14.7961 5.83592 14.8078 5.75389 14.8172C6.10076 14.7727 6.44529 14.7703 6.79451 14.7703C7.22342 14.7703 7.65233 14.7703 8.08123 14.7703C9.08201 14.7703 10.0828 14.7703 11.0836 14.7703C11.4703 14.7703 11.8547 14.768 12.2414 14.8172C12.1594 14.8055 12.075 14.7938 11.993 14.7844C12.4734 14.85 12.9445 14.9766 13.3922 15.1664C13.3172 15.136 13.2422 15.1032 13.1672 15.0727C13.5937 15.2555 13.9945 15.4899 14.3625 15.7735C14.2992 15.7242 14.2359 15.675 14.1726 15.6258C14.5359 15.9094 14.864 16.2352 15.1476 16.6008C15.0984 16.5375 15.0492 16.4742 15 16.411C15.2836 16.7789 15.518 17.1797 15.7008 17.6063C15.6703 17.5313 15.6375 17.4563 15.607 17.3813C15.7945 17.8289 15.9234 18.2977 15.9891 18.7805C15.9773 18.6985 15.9656 18.6141 15.9562 18.5321C16.0008 18.886 16.0031 19.2375 16.0031 19.5938C16.0031 19.9805 16.0031 20.3672 16.0031 20.7539C16.0031 20.8875 16.0078 21.0211 15.9914 21.1524C16.0031 21.0703 16.0148 20.986 16.0242 20.9039C16.0101 20.9977 15.9844 21.0867 15.9492 21.1735C15.9797 21.0985 16.0125 21.0235 16.043 20.9485C16.0031 21.0422 15.9516 21.1289 15.8883 21.211C15.9375 21.1477 15.9867 21.0844 16.0359 21.0211C15.9773 21.0914 15.9141 21.1571 15.8437 21.2133C15.907 21.1641 15.9703 21.1149 16.0336 21.0657C15.9516 21.1289 15.8648 21.1782 15.7711 21.2203C15.8461 21.1899 15.9211 21.1571 15.9961 21.1266C15.9094 21.1617 15.818 21.1852 15.7266 21.2016C15.8086 21.1899 15.893 21.1782 15.975 21.1688C15.9234 21.1758 15.8695 21.1782 15.8156 21.1805C15.5742 21.1828 15.3258 21.2836 15.1523 21.4547C14.9906 21.6164 14.8664 21.8836 14.8781 22.118C14.9015 22.6196 15.2906 23.0625 15.8156 23.0555C16.7273 23.0414 17.5289 22.4461 17.7961 21.5719C17.9016 21.225 17.8781 20.8524 17.8781 20.4961C17.8781 19.6805 17.9039 18.8719 17.7633 18.0633C17.557 16.8797 16.9617 15.7664 16.1461 14.8922C15.3305 14.018 14.2336 13.3758 13.0734 13.0899C12.4078 12.9258 11.7375 12.9 11.0578 12.9C10.3594 12.9 9.66327 12.9 8.96483 12.9C8.27576 12.9 7.58904 12.9 6.89998 12.9C6.20389 12.9 5.51248 12.9328 4.83514 13.1133C3.68435 13.418 2.60154 14.0672 1.80232 14.9485C0.99607 15.8367 0.412476 16.9524 0.222632 18.143C0.0960691 18.9422 0.12185 19.7438 0.12185 20.55C0.12185 20.9203 0.100757 21.3071 0.23435 21.661C0.407788 22.1157 0.684351 22.4742 1.08982 22.7438C1.40623 22.9524 1.80701 23.0532 2.18201 23.0578C2.36482 23.0602 2.54763 23.0578 2.73045 23.0578C3.1992 23.0578 3.6656 23.0578 4.13435 23.0578C4.79998 23.0578 5.46326 23.0578 6.12889 23.0578C6.90233 23.0578 7.67576 23.0578 8.4492 23.0578C9.24373 23.0578 10.0359 23.0578 10.8305 23.0578C11.557 23.0578 12.2812 23.0578 13.0078 23.0578C13.5773 23.0578 14.1469 23.0578 14.714 23.0578C15.0398 23.0578 15.3656 23.0578 15.6914 23.0578C15.7336 23.0578 15.7758 23.0578 15.818 23.0578C16.3078 23.0578 16.7789 22.6266 16.7555 22.1203C16.732 21.6094 16.343 21.1805 15.8156 21.1805Z" fill="white"/>
														</svg>
													</div>	
													<div class="ms-2">
														<span class="mb-0">Class</span>
														<h6 class="text-primary mb-0 font-w600">VII B</h6>
													</div>
												</div>
											</td>
											<td><span class="doller font-w600"> $ 54,036</span></td>
											<td>First</td>
											<td>
												<ul class="tbl-action">
													<li>	
														<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
															<g clip-path="url(#clip0_6_400-3)">
															<path d="M23 19H18.93C18.6648 19 18.4104 18.8946 18.2229 18.7071C18.0354 18.5196 17.93 18.2652 17.93 18V15H6V18C6 18.2652 5.89464 18.5196 5.70711 18.7071C5.51957 18.8946 5.26522 19 5 19H1C0.734784 19 0.48043 18.8946 0.292893 18.7071C0.105357 18.5196 0 18.2652 0 18V8C0 7.20435 0.31607 6.44129 0.87868 5.87868C1.44129 5.31607 2.20435 5 3 5H21C21.7956 5 22.5587 5.31607 23.1213 5.87868C23.6839 6.44129 24 7.20435 24 8V18C24 18.2652 23.8946 18.5196 23.7071 18.7071C23.5196 18.8946 23.2652 19 23 19ZM19.93 17H22V8C22.0015 7.86827 21.9766 7.73757 21.9269 7.61558C21.8771 7.49359 21.8035 7.38276 21.7104 7.28961C21.6172 7.19646 21.5064 7.12285 21.3844 7.07312C21.2624 7.02339 21.1317 6.99853 21 7H3C2.86827 6.99853 2.73757 7.02339 2.61558 7.07312C2.49359 7.12285 2.38276 7.19646 2.28961 7.28961C2.19646 7.38276 2.12285 7.49359 2.07312 7.61558C2.02339 7.73757 1.99853 7.86827 2 8V17H4V14C4 13.7348 4.10536 13.4804 4.29289 13.2929C4.48043 13.1054 4.73478 13 5 13H18.93C19.1952 13 19.4496 13.1054 19.6371 13.2929C19.8246 13.4804 19.93 13.7348 19.93 14V17Z" fill="#A098AE"/>
															<path d="M18.9331 7H5.00012C4.73491 7 4.48055 6.89464 4.29302 6.70711C4.10548 6.51957 4.00012 6.26522 4.00012 6V1C4.00012 0.734784 4.10548 0.48043 4.29302 0.292893C4.48055 0.105357 4.73491 0 5.00012 0L18.9331 0C19.1983 0 19.4527 0.105357 19.6402 0.292893C19.8278 0.48043 19.9331 0.734784 19.9331 1V6C19.9331 6.26522 19.8278 6.51957 19.6402 6.70711C19.4527 6.89464 19.1983 7 18.9331 7ZM6.00012 5H17.9331V2H6.00012V5ZM17.0331 24H6.90012C6.13099 24 5.39337 23.6945 4.84951 23.1506C4.30566 22.6068 4.00012 21.8691 4.00012 21.1V14C4.00012 13.7348 4.10548 13.4804 4.29302 13.2929C4.48055 13.1054 4.73491 13 5.00012 13H18.9301C19.1953 13 19.4497 13.1054 19.6372 13.2929C19.8248 13.4804 19.9301 13.7348 19.9301 14V21.1C19.9301 21.8686 19.625 22.6058 19.0818 23.1495C18.5386 23.6933 17.8017 23.9992 17.0331 24ZM6.00012 15V21.1C6.00012 21.3387 6.09494 21.5676 6.26373 21.7364C6.43251 21.9052 6.66143 22 6.90012 22H17.0331C17.2718 22 17.5007 21.9052 17.6695 21.7364C17.8383 21.5676 17.9331 21.3387 17.9331 21.1V15H6.00012ZM20.0001 10H19.0001C18.7349 10 18.4806 9.89464 18.293 9.70711C18.1055 9.51957 18.0001 9.26522 18.0001 9C18.0001 8.73478 18.1055 8.48043 18.293 8.29289C18.4806 8.10536 18.7349 8 19.0001 8H20.0001C20.2653 8 20.5197 8.10536 20.7072 8.29289C20.8948 8.48043 21.0001 8.73478 21.0001 9C21.0001 9.26522 20.8948 9.51957 20.7072 9.70711C20.5197 9.89464 20.2653 10 20.0001 10Z" fill="#A098AE"/>
															<path d="M14.9999 18H8.99988C8.73466 18 8.48031 17.8946 8.29277 17.7071C8.10523 17.5196 7.99988 17.2652 7.99988 17C7.99988 16.7348 8.10523 16.4804 8.29277 16.2929C8.48031 16.1054 8.73466 16 8.99988 16H14.9999C15.2651 16 15.5194 16.1054 15.707 16.2929C15.8945 16.4804 15.9999 16.7348 15.9999 17C15.9999 17.2652 15.8945 17.5196 15.707 17.7071C15.5194 17.8946 15.2651 18 14.9999 18ZM11.9999 21H8.99988C8.73466 21 8.48031 20.8946 8.29277 20.7071C8.10523 20.5196 7.99988 20.2652 7.99988 20C7.99988 19.7348 8.10523 19.4804 8.29277 19.2929C8.48031 19.1054 8.73466 19 8.99988 19H11.9999C12.2651 19 12.5194 19.1054 12.707 19.2929C12.8945 19.4804 12.9999 19.7348 12.9999 20C12.9999 20.2652 12.8945 20.5196 12.707 20.7071C12.5194 20.8946 12.2651 21 11.9999 21Z" fill="#A098AE"/>
															</g>
															<defs>
															<clipPath id="clip0_6_400-3">
															<rect width="24" height="24" fill="white"/>
															</clipPath>
															</defs>
														</svg>
														<div class="dropdown custom-dropdown ">
															<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
																<svg width="18" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
																	<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
																</svg>
															</div>
															<div class="dropdown-menu dropdown-menu-end">
																<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
																<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
															</div>
														</div>
													</li>
												</ul>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
        <!--**********************************
            Content body end
        ***********************************-->
		<!--**********************************
			Footer start
		***********************************-->
		<?php include 'elements/footer.php'; ?>

	</div>

	
    <!--**********************************
        Main wrapper end
    ***********************************-->

<!--***********************************-->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-dialog-center">
		<div class="modal-content">
			<div class="modal-header">
			<h5 class="modal-title" id="exampleModalLabel">Recent Student title</h5>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-xl-6">
						<div class="mb-3">
						  <label for="exampleFormControlInput1" class="form-label mb-2">Student Name</label>
						  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="James">
						</div>
						<div class="mb-3">
						  <label for="exampleFormControlInput2" class="form-label mb-2">Email</label>
						  <input type="email" class="form-control" id="exampleFormControlInput2" placeholder="hello@example.com">
						</div>
						<div class="mb-3">
						  <label  class="form-label mb-2">Gender</label>
						  <select class="default-select wide" aria-label="Default select example">
							  <option selected>Select Option</option>
							  <option value="1">Male</option>
							  <option value="2">Women</option>
							  <option value="3">Other</option>
							</select>
						</div>
					</div>
					<div class="col-xl-6">
						<div class="mb-3">
						  <label for="exampleFormControlInput4" class="form-label mb-2">Entery Year</label>
						  <input type="number" class="form-control" id="exampleFormControlInput4" placeholder="EX: 2023">
						</div>
						<div class="mb-3">
						  <label for="exampleFormControlInput5" class="form-label mb-2">Student ID</label>
						  <input type="number" class="form-control" id="exampleFormControlInput5" placeholder="14EMHEE092">
						</div>
						<div class="mb-3">
						  <label for="exampleFormControlInput6" class="form-label mb-2">Phone Number</label>
						  <input type="number" class="form-control" id="exampleFormControlInput6" placeholder="+123456">
						</div>
					</div>
				</div>
				
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			</div>
		</div>
		</div>
	</div>	

		
	<!--**********************************
		Modal
	***********************************-->
    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <?php include 'elements/page-js.php'; ?>
</body>
</html>