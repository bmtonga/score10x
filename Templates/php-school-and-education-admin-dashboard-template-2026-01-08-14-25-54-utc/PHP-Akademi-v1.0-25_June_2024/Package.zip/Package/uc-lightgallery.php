<?php 
	 require_once __DIR__ . '/config/dz.php';
?>
<!DOCTYPE html>

<html lang="en">

<head>
		<!-- PAGE TITLE HERE -->
		 <title><?php echo $DexignZoneSettings['site_level']['site_title'] ?></title>
		 <?php include 'elements/meta.php';?>
		 <!-- FAVICONS ICON -->
		 <link rel="shortcut icon" type="image/png" href="<?php echo $DexignZoneSettings['site_level']['favicon']?>">
		 
		 <?php include 'elements/page-css.php'; ?>
	 </head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    	
    <?php include 'elements/pre-loader.php'; ?>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
           <?php include 'elements/nav-header.php'; ?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Chat box start
        ***********************************-->
		<?php include 'elements/chatbox.php'; ?>
		<!--**********************************
            Chat box End
        ***********************************-->

        <!--**********************************
            Header start
        ***********************************-->

		<?php include 'elements/header.php'; ?>

		<!-- Header-end -->
      

        <!--**********************************
            Sidebar start
        ***********************************-->
      <?php include 'elements/sidebar.php'; ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
				
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
							<div class="card-header">
								<h4 class="card-title">Light Gallery</h4>
							</div>
							<div class="card-body pb-1">
								<div id="lightgallery" class="row">
									<a href="assets/images/big/img1.jpg" data-exthumbimage="assets/images/big/img1.jpg" data-src="assets/images/big/img1.jpg" class="col-lg-3 col-6 mb-4">
										<img src="assets/images/big/img1.jpg" alt="" style="width:100%;">
									</a>
									<a href="assets/images/big/img2.jpg" data-exthumbimage="assets/images/big/img2.jpg" data-src="assets/images/big/img2.jpg" class="col-lg-3 col-6 mb-4">
										<img src="assets/images/big/img2.jpg" alt="" style="width:100%;">                                                           
									</a>                                                                                                                     
									<a href="assets/images/big/img3.jpg" data-exthumbimage="assets/images/big/img3.jpg" data-src="assets/images/big/img3.jpg" class="col-lg-3 col-6 mb-4">
										<img src="assets/images/big/img3.jpg" alt="" style="width:100%;">                                                           
									</a>                                                                                                                     
									<a href="assets/images/big/img4.jpg" data-exthumbimage="assets/images/big/img4.jpg" data-src="assets/images/big/img4.jpg" class="col-lg-3 col-6 mb-4">
										<img src="assets/images/big/img4.jpg" alt="" style="width:100%;">                                                           
									</a>                                                                                                                     
									<a href="assets/images/big/img5.jpg" data-exthumbimage="assets/images/big/img5.jpg" data-src="assets/images/big/img5.jpg" class="col-lg-3 col-6 mb-4">
										<img src="assets/images/big/img5.jpg" alt="" style="width:100%;">                                                           
									</a>                                                                                                                     
									<a href="assets/images/big/img6.jpg" data-exthumbimage="assets/images/big/img6.jpg" data-src="assets/images/big/img6.jpg" class="col-lg-3 col-6 mb-4">
										<img src="assets/images/big/img6.jpg" alt="" style="width:100%;">                                                           
									</a>                                                                                                                     
									<a href="assets/images/big/img7.jpg" data-exthumbimage="assets/images/big/img7.jpg" data-src="assets/images/big/img7.jpg" class="col-lg-3 col-6 mb-4">
										<img src="assets/images/big/img7.jpg" alt="" style="width:100%;">                                                           
									</a>                                                                                                                     
									<a href="assets/images/big/img8.jpg" data-exthumbimage="assets/images/big/img8.jpg" data-src="assets/images/big/img8.jpg" class="col-lg-3 col-6 mb-4">
										<img src="assets/images/big/img8.jpg" alt="" style="width:100%;">
									</a>
								</div>
							</div>
                        </div>
                        <!-- /# card -->
                    </div>
				<div class="col-xl-4">
					<div class="card ">
						<div class="card-body p-3">
								<div id="lightgallery-1" class="row g-2">
									<a href="assets/images/big/pic1.jpg" data-exthumbimage="assets/images/big/pic1.jpg" data-src="assets/images/big/pic1.jpg" class="col-lg-4  col-4">
										<img src="assets/images/big/pic1.jpg"  alt="" style="width:100%;">
									</a>
									<a href="assets/images/big/pic2.jpg" data-exthumbimage="assets/images/big/pic2.jpg" data-src="assets/images/big/pic2.jpg" class="col-lg-4  col-4">
										<img src="assets/images/big/pic2.jpg"  alt="" style="width:100%;">
									</a>
									<a href="assets/images/big/pic3.jpg" data-exthumbimage="assets/images/big/pic3.jpg" data-src="assets/images/big/pic3.jpg" class="col-lg-4  col-4 ">
										<img src="assets/images/big/pic3.jpg"  alt="" style="width:100%;">                                                             
									</a>                                                                                                                        
									<a href="assets/images/big/pic4.jpg" data-exthumbimage="assets/images/big/pic4.jpg" data-src="assets/images/big/pic4.jpg" class="col-lg-4  col-4 ">
										<img src="assets/images/big/pic4.jpg"  alt="" style="width:100%;">                                                             
									</a>                                                                                                                        
									<a href="assets/images/big/pic5.jpg" data-exthumbimage="assets/images/big/pic5.jpg" data-src="assets/images/big/pic5.jpg" class="col-lg-4  col-4 ">
										<img src="assets/images/big/pic5.jpg"  alt="" style="width:100%;">                                                             
									</a>                                                                                                                        
									<a href="assets/images/big/pic6.jpg" data-exthumbimage="assets/images/big/pic6.jpg" data-src="assets/images/big/pic6.jpg" class="col-lg-4  col-4 ">
										<img src="assets/images/big/pic6.jpg"  alt="" style="width:100%;">                                                             
									</a>                                                                                                                        
									<a href="assets/images/big/pic7.jpg" data-exthumbimage="assets/images/big/pic7.jpg" data-src="assets/images/big/pic7.jpg" class="col-lg-4  col-4 ">
										<img src="assets/images/big/pic7.jpg"  alt="" style="width:100%;">                                                             
									</a>                                                                                                                        
									<a href="assets/images/big/pic8.jpg" data-exthumbimage="assets/images/big/pic8.jpg" data-src="assets/images/big/pic8.jpg" class="col-lg-4  col-4 ">
										<img src="assets/images/big/pic8.jpg"  alt="" style="width:100%;">                                                             
									</a>                                                                                                                        
									<a href="assets/images/big/pic1.jpg" data-exthumbimage="assets/images/big/pic1.jpg" data-src="assets/images/big/pic1.jpg" class="col-lg-4  col-4 ">
										<img src="assets/images/big/pic1.jpg"  alt="" style="width:100%;">                                                             
									</a>                                                                                                                          
								</div>
							</div>
					</div>
				</div>
				<div class="col-xl-8">
					<div class="card h-auto">
						<div class="card-body p-3">
								<div id="lightgallery-2" class="row g-2">
									<a href="assets/images/big/pic9.jpg" data-exthumbimage="assets/images/big/pic9.jpg" data-src="assets/images/big/pic9.jpg" class="col-lg-12  col-12">
										<img src="assets/images/big/pic9.jpg"  alt="" style="width:100%;">
									</a>
									<a href="assets/images/big/pic2.jpg" data-exthumbimage="assets/images/big/pic2.jpg" data-src="assets/images/big/pic2.jpg" class="col-lg-2  col-2">
										<img src="assets/images/big/pic2.jpg"  alt="" style="width:100%;">
									</a>
									<a href="assets/images/big/pic3.jpg" data-exthumbimage="assets/images/big/pic3.jpg" data-src="assets/images/big/pic3.jpg" class="col-lg-2  col-2 ">
										<img src="assets/images/big/pic3.jpg"  alt="" style="width:100%;">                                                               
									</a>                                                                                                                          
									<a href="assets/images/big/pic4.jpg" data-exthumbimage="assets/images/big/pic4.jpg" data-src="assets/images/big/pic4.jpg" class="col-lg-2  col-2 ">
										<img src="assets/images/big/pic4.jpg"  alt="" style="width:100%;">                                                               
									</a>                                                                                                                          
									<a href="assets/images/big/pic5.jpg" data-exthumbimage="assets/images/big/pic5.jpg" data-src="assets/images/big/pic5.jpg" class="col-lg-2  col-2 ">
										<img src="assets/images/big/pic5.jpg"  alt="" style="width:100%;">                                                               
									</a>                                                                                                                          
									<a href="assets/images/big/pic6.jpg" data-exthumbimage="assets/images/big/pic6.jpg" data-src="assets/images/big/pic6.jpg" class="col-lg-2  col-2 ">
										<img src="assets/images/big/pic6.jpg"  alt="" style="width:100%;">                                                               
									</a>                                                                                                                          
									<a href="assets/images/big/pic7.jpg" data-exthumbimage="assets/images/big/pic7.jpg" data-src="assets/images/big/pic7.jpg" class="col-lg-2  col-2">
										<img src="assets/images/big/pic7.jpg"  alt="" style="width:100%;">                                                               
									</a>                                                                                                                          
									                                 
									
								</div>
							</div>
					</div>
				</div>
                </div>
				 
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->
<!--**********************************
			Footer start
		***********************************-->
		<?php include 'elements/footer.php'; ?>
		<!--**********************************
			Footer end
		***********************************-->
        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <?php include 'elements/page-js.php'; ?>
</body>

</html>