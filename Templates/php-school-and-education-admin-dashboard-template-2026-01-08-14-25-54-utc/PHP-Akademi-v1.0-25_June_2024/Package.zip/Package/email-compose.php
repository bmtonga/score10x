<?php 
	 require_once __DIR__ . '/config/dz.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
		<!-- PAGE TITLE HERE -->
		 <title><?php echo $DexignZoneSettings['site_level']['site_title'] ?></title>
		 <?php include 'elements/meta.php';?>
		 <!-- FAVICONS ICON -->
		 <link rel="shortcut icon" type="image/png" href="<?php echo $DexignZoneSettings['site_level']['favicon']?>">
		 
		 <?php include 'elements/page-css.php'; ?>
	 </head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    	
    <?php include 'elements/pre-loader.php'; ?>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
		  <?php include 'elements/nav-header.php'; ?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Chat box start
        ***********************************-->
		<?php include 'elements/chatbox.php'; ?>
		<!--**********************************
            Chat box End
        ***********************************-->
		
        <!--**********************************
            Header start
        ***********************************-->
		<?php include 'elements/header.php'; ?>
                    
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
      <?php include 'elements/sidebar.php'; ?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body mh-auto">
            <div class="container-fluid p-0">
                <!-- row -->
                <div class="row gx-0">
                    <div class="col-lg-12">
                        <div class="card rounded-0 mb-0 h-auto">
                            <div class="card-body p-0 ">
								<div class="row gx-0">
									<!--column-->
									<div class="col-lg-3 col-xl-2 col-xxl-3">
										<div class="email-left-box dlab-scroll pt-3" id="email-left">
											<div class="p-0">
												<a href="email-compose.php" class="btn text-white btn-block"><i class="fa-solid fa-plus me-2"></i>Compose Email</a>
											</div>
											<div class="mail-list rounded ">
												<a href="email-inbox.php" class="list-group-item active"><i class="fa-regular fa-envelope align-middle"></i>Inbox <span class="badge badge-purple badge-sm float-end rounded">2</span> </a>
												<a href="javascript:void(0);" class="list-group-item"><i class="fa-regular fa-paper-plane align-middle"></i>Sent</a> 	
												<a href="javascript:void(0);" class="list-group-item"><i class="fa-regular fa-star align-middle"></i>Favorite </a>
												<a href="javascript:void(0);" class="list-group-item"><i class="fa-regular fa-file align-middle"></i>Draft</a>
												<a href="javascript:void(0);" class="list-group-item ">
												<svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" >
													<path d="M15.4425 10.0575L10.065 15.435C9.92569 15.5745 9.76026 15.6851 9.57816 15.7606C9.39606 15.8361
													9.20087 15.8749 9.00375 15.8749C8.80663 15.8749 8.61144 15.8361 8.42934 15.7606C8.24724 15.6851 8.08181 15.5745 7.9425 15.435L1.5 9V1.5H9L15.4425
													7.9425C15.7219 8.22354 15.8787 8.60372 15.8787 9C15.8787 9.39628 15.7219 9.77646 15.4425 10.0575Z"
													stroke="#666666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
													<path d="M5.25 5.25H5.268" stroke="#666666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
												</svg>Important</a>		
												<a href="javascript:void(0);" class="list-group-item"><i class="fa-regular fa-clock align-middle"></i> Scheduled</a>
													
												
												<a href="javascript:void(0);" class="list-group-item">
													<svg width="15" height="15" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M5.5 8.25L11 13.75L16.5 8.25" stroke="#666666" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
													</svg>
													Move
												</a>
											</div>
											<div class="mail-list rounded overflow-hidden mt-4">
												<div class="intro-title d-flex justify-content-between my-0">
													<h5>Categories</h5>
												</div>
												<a href="email-inbox.php" class="list-group-item change">Work </a>
												<a href="email-inbox.php" class="list-group-item change">Private </a>
												<a href="email-inbox.php" class="list-group-item change">Support </a>
												<a href="email-inbox.php" class="list-group-item change">Social </a>
											</div>
										</div>
									</div>
									<!--/column-->
									<div class="col-lg-9 col-xl-10 col-xxl-9">
										<div class="email-right-box ms-0 mt-3 ">
											<div class="compose-wrapper " id="compose-content">
												<div class="compose-content">
													<form action="#">
														<div class="mb-3">
															<input type="text" class="form-control bg-transparent" placeholder=" To:">
														</div>
														<div class="mb-3">
															<input type="text" class="form-control bg-transparent" placeholder=" Subject:">
														</div>
														<div class="mb-3">
															<textarea id="email-compose-editor" class="textarea_editor form-control bg-transparent" rows="5" placeholder="Enter text ..."></textarea>
														</div>
													</form>
													<h5 class="my-3"><i class="fa fa-paperclip me-2"></i> Attatchment</h5>
													<form action="#" class="dropzone">
														<div class="fallback">
															<input name="file" type="file" multiple >
														</div>
													</form>
												</div>
												<div class="text-start mt-4 mb-3">
													<button class="btn btn-primary btn-sl-sm me-2" type="button"><span class="me-2"><i class="fa fa-paper-plane"></i></span>Send</button>
													<button class="btn btn-danger light btn-sl-sm" type="button"><span class="me-2"><i class="fa fa-times"></i></span>Discard</button>
												</div>
											</div>
										</div>
									</div>
								</div>
                                
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


      
        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <?php include 'elements/page-js.php'; ?>
	
</body>
</html>