<?php 
	 require_once __DIR__ . '/config/dz.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
		<!-- PAGE TITLE HERE -->
		 <title><?php echo $DexignZoneSettings['site_level']['site_title'] ?></title>
		 <?php include 'elements/meta.php';?>
		 <!-- FAVICONS ICON -->
		 <link rel="shortcut icon" type="image/png" href="<?php echo $DexignZoneSettings['site_level']['favicon']?>">
		 
		 <?php include 'elements/page-css.php'; ?>
	 </head>
<body>

    <!--*******************
        Preloader start
    ********************-->
	 	
    <?php include 'elements/pre-loader.php'; ?>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">
	
        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="index.php" class="brand-logo">
				<svg class="logo-abbr" width="48" height="54" viewBox="0 0 48 54" fill="none" xmlns="http://www.w3.org/2000/svg">
					<rect y="3" width="48" height="48" rx="16" fill="#FB7D5B"/>
					<path d="M28.964 35.536H19.532L18.02 40H11.576L20.72 14.728H27.848L36.992 40H30.476L28.964 35.536ZM27.38 30.784L24.248 21.532L21.152 30.784H27.38Z" fill="white"/>
				</svg>
				<div class="brand-title">
					<svg width="140" height="30" viewBox="0 0 167 30" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M17.964 24.536H8.532L7.02 29H0.576L9.72 3.728H16.848L25.992 29H19.476L17.964 24.536ZM16.38 19.784L13.248 10.532L10.152 19.784H16.38ZM41.051 29L34.931 20.576V29H28.775V2.36H34.931V17.084L41.015 8.912H48.611L40.259 18.992L48.683 29H41.051ZM49.8049 18.92C49.8049 16.856 50.1889 15.044 50.9569 13.484C51.7489 11.924 52.8169 10.724 54.1609 9.884C55.5049 9.044 57.0049 8.624 58.6609 8.624C60.0769 8.624 61.3129 8.912 62.3689 9.488C63.4489 10.064 64.2769 10.82 64.8529 11.756V8.912H71.0089V29H64.8529V26.156C64.2529 27.092 63.4129 27.848 62.3329 28.424C61.2769 29 60.0409 29.288 58.6249 29.288C56.9929 29.288 55.5049 28.868 54.1609 28.028C52.8169 27.164 51.7489 25.952 50.9569 24.392C50.1889 22.808 49.8049 20.984 49.8049 18.92ZM64.8529 18.956C64.8529 17.42 64.4209 16.208 63.5569 15.32C62.7169 14.432 61.6849 13.988 60.4609 13.988C59.2369 13.988 58.1929 14.432 57.3289 15.32C56.4889 16.184 56.0689 17.384 56.0689 18.92C56.0689 20.456 56.4889 21.68 57.3289 22.592C58.1929 23.48 59.2369 23.924 60.4609 23.924C61.6849 23.924 62.7169 23.48 63.5569 22.592C64.4209 21.704 64.8529 20.492 64.8529 18.956ZM74.2385 18.92C74.2385 16.856 74.6225 15.044 75.3905 13.484C76.1825 11.924 77.2505 10.724 78.5945 9.884C79.9385 9.044 81.4385 8.624 83.0945 8.624C84.4145 8.624 85.6145 8.9 86.6945 9.452C87.7985 10.004 88.6625 10.748 89.2865 11.684V2.36H95.4425V29H89.2865V26.12C88.7105 27.08 87.8825 27.848 86.8025 28.424C85.7465 29 84.5105 29.288 83.0945 29.288C81.4385 29.288 79.9385 28.868 78.5945 28.028C77.2505 27.164 76.1825 25.952 75.3905 24.392C74.6225 22.808 74.2385 20.984 74.2385 18.92ZM89.2865 18.956C89.2865 17.42 88.8545 16.208 87.9905 15.32C87.1505 14.432 86.1185 13.988 84.8945 13.988C83.6705 13.988 82.6265 14.432 81.7625 15.32C80.9225 16.184 80.5025 17.384 80.5025 18.92C80.5025 20.456 80.9225 21.68 81.7625 22.592C82.6265 23.48 83.6705 23.924 84.8945 23.924C86.1185 23.924 87.1505 23.48 87.9905 22.592C88.8545 21.704 89.2865 20.492 89.2865 18.956ZM118.832 18.632C118.832 19.208 118.796 19.808 118.724 20.432H104.792C104.888 21.68 105.284 22.64 105.98 23.312C106.7 23.96 107.576 24.284 108.608 24.284C110.144 24.284 111.212 23.636 111.812 22.34H118.364C118.028 23.66 117.416 24.848 116.528 25.904C115.664 26.96 114.572 27.788 113.252 28.388C111.932 28.988 110.456 29.288 108.824 29.288C106.856 29.288 105.104 28.868 103.568 28.028C102.032 27.188 100.832 25.988 99.9681 24.428C99.1041 22.868 98.6721 21.044 98.6721 18.956C98.6721 16.868 99.0921 15.044 99.9321 13.484C100.796 11.924 101.996 10.724 103.532 9.884C105.068 9.044 106.832 8.624 108.824 8.624C110.768 8.624 112.496 9.032 114.008 9.848C115.52 10.664 116.696 11.828 117.536 13.34C118.4 14.852 118.832 16.616 118.832 18.632ZM112.532 17.012C112.532 15.956 112.172 15.116 111.452 14.492C110.732 13.868 109.832 13.556 108.752 13.556C107.72 13.556 106.844 13.856 106.124 14.456C105.428 15.056 104.996 15.908 104.828 17.012H112.532ZM147.712 8.696C150.208 8.696 152.188 9.452 153.652 10.964C155.14 12.476 155.884 14.576 155.884 17.264V29H149.764V18.092C149.764 16.796 149.416 15.8 148.72 15.104C148.048 14.384 147.112 14.024 145.912 14.024C144.712 14.024 143.764 14.384 143.068 15.104C142.396 15.8 142.06 16.796 142.06 18.092V29H135.94V18.092C135.94 16.796 135.592 15.8 134.896 15.104C134.224 14.384 133.288 14.024 132.088 14.024C130.888 14.024 129.94 14.384 129.244 15.104C128.572 15.8 128.236 16.796 128.236 18.092V29H122.08V8.912H128.236V11.432C128.86 10.592 129.676 9.932 130.684 9.452C131.692 8.948 132.832 8.696 134.104 8.696C135.616 8.696 136.96 9.02 138.136 9.668C139.336 10.316 140.272 11.24 140.944 12.44C141.64 11.336 142.588 10.436 143.788 9.74C144.988 9.044 146.296 8.696 147.712 8.696ZM163.285 6.824C162.205 6.824 161.317 6.512 160.621 5.888C159.949 5.24 159.613 4.448 159.613 3.512C159.613 2.552 159.949 1.76 160.621 1.136C161.317 0.487998 162.205 0.163998 163.285 0.163998C164.341 0.163998 165.205 0.487998 165.877 1.136C166.573 1.76 166.921 2.552 166.921 3.512C166.921 4.448 166.573 5.24 165.877 5.888C165.205 6.512 164.341 6.824 163.285 6.824ZM166.345 8.912V29H160.189V8.912H166.345Z" fill="white"/>
					</svg>
				</div>
            </a>
            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
					<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
						<rect x="22" y="11" width="4" height="4" rx="2" fill="#2A353A"/>
						<rect x="11" width="4" height="4" rx="2" fill="#2A353A"/>
						<rect x="22" width="4" height="4" rx="2" fill="#2A353A"/>
						<rect x="11" y="11" width="4" height="4" rx="2" fill="#2A353A"/>
						<rect x="11" y="22" width="4" height="4" rx="2" fill="#2A353A"/>
						<rect width="4" height="4" rx="2" fill="#2A353A"/>
						<rect y="11" width="4" height="4" rx="2" fill="#2A353A"/>
						<rect x="22" y="22" width="4" height="4" rx="2" fill="#2A353A"/>
						<rect y="22" width="4" height="4" rx="2" fill="#2A353A"/>
					</svg>		
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Chat box start
        ***********************************-->
		<?php include 'elements/chatbox.php'; ?>
		<!--**********************************
            Chat box End
        ***********************************-->
		
		<!--**********************************
            Header start
        ***********************************-->
		<?php include 'elements/header.php'; ?>
			<!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include 'elements/sidebar.php'; ?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
				<!-- Row -->
				<div class="row">
					<div class="col-xl-9">
						<div class="card h-auto">
							<div class="card-header p-0">
								<div class="user-bg w-100">
									<div class="user-svg">
										<svg width="261" height="109" viewBox="0 0 261 109" fill="none" xmlns="http://www.w3.org/2000/svg">
											<rect y="0.6521" width="261" height="275.13" rx="130.5" fill="#FCC43E"/>
										</svg>
									</div>
									<div class="user-svg-1">
										<svg width="261" height="63" viewBox="0 0 261 63" fill="none" xmlns="http://www.w3.org/2000/svg">
											<rect width="261" height="275.13" rx="130.5" fill="#FB7D5B"/>
										</svg>
									</div>
								</div>
							</div>
							<div class="card-body">
								<div class="d-flex justify-content-between">
									<div class="user">
										<div class="user-media">
											<img src="assets/images/avatar/10.jpg" alt="" class="avatar avatar-xxl">
										</div>
										<div>
											<h2 class="mb-0">Nabila Azalea</h2>
											<p class="text-primary">Admin</p>
										</div>
									</div>
									<div class="dropdown custom-dropdown">
										<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
											<svg width="24" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
												<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#A098AE"/>
											</svg>
										</div>
										<div class="dropdown-menu dropdown-menu-end">
											<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
											<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
											<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
										</div>
									</div>
								</div>
								<div class="row mt-2">
									<div class="col-xl-3 col-xxl-6 col-sm-6">
										<ul class="student-details">
											<li class="me-2">
												<a class="icon-box bg-secondary">
													<img src="assets/images/profile.svg" alt="">
												</a>
											</li>
											<li>
												<span>Parents:</span>
												<h5 class="mb-0">Justin Hope</h5>
											</li>
										</ul>
									</div>
									<div class="col-xl-3 col-xxl-6 col-sm-6">
										
										<ul class="student-details">
											<li class="me-2">
												<a class="icon-box bg-secondary">
													<img src="assets/images/svg/location.svg" alt="">
												</a>	

											</li>
											<li><span>Address:</span><h5 class="mb-0">Jakarta, Indonesia</h5></li>
										</ul>
									</div>
									<div class="col-xl-3 col-xxl-6 col-sm-6">
										<ul class="student-details">
											<li class="me-2">
												<a class="icon-box bg-secondary">
													<img src="assets/images/svg/phone.svg" alt="">
												</a>	
											</li>
											<li><span>Phone:</span><h5 class="mb-0">+12 345 6789 0</h5></li>
										</ul>
									</div>
									<div class="col-xl-3 col-xxl-6 col-sm-6">
										<ul class="student-details">
											<li class="me-2">
												<a class="icon-box bg-secondary">
													<img src="assets/images/svg/email.svg" alt="">
												</a>	
											
											</li>
											<li><span>Email:</span><h5 class="mb-0">Historia@mail.com</h5></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-xl-6 col-lg-6 col-md-12">
								<div class="card">
									<div class="card-header border-0 pb-0 d-block">
										<div class="d-flex align-items-center justify-content-between">
											<div>
												<h3 class="heading">Contacts</h3>
												<span>You have <span class="font-w600">456</span> contacts</span>
											</div>
											<button type="button" class="icon-box icon-box-sm bg-primary border-0" data-bs-toggle="modal" data-bs-target="#exampleModal">
											 <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M5.87826 10.0611H0V5.869H5.87826V0H10.0522V5.869H16V10.0611H10.0522V16H5.87826V10.0611Z" fill="white"/>
											</svg>
											</button>
										</div>	
										<div class="input-group user-search-area flex-nowrap">
										  <span class="input-group-text" id="addon-wrapping-1"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M23.6 21.8001L18 16.2001C19.3 14.5001 20.1 12.4001 20.1 10.1001C20.1 4.6001 15.6 0.100098 10.1 0.100098C4.6 0.100098 0 4.6001 0 10.1001C0 15.6001 4.5 20.1001 10 20.1001C12.3 20.1001 14.5 19.3001 16.2 17.9001L21.8 23.5001C22 23.7001 22.4 23.9001 22.7 23.9001C23 23.9001 23.3 23.8001 23.6 23.5001C24.1 23.1001 24.1 22.3001 23.6 21.8001ZM2.5 10.1001C2.5 6.0001 5.9 2.6001 10 2.6001C14.1 2.6001 17.5 6.0001 17.5 10.1001C17.5 14.2001 14.1 17.6001 10 17.6001C5.9 17.6001 2.5 14.3001 2.5 10.1001Z" fill="var(--primary)"/>
											</svg>
											</span>
										  <input type="text" class="form-control ps-0" placeholder="Contacts" aria-label="Username" aria-describedby="addon-wrapping">
										</div>
									</div>
									<div class="card-body pt-0 pb-0 height450 dz-scroll">
										<div class="contacts-list"  id="RecentActivityContent">
											<div class="d-flex justify-content-between mb-3 mt-3 pb-3 user border-bottom">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic4.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="app-profile.php">Samanta William</a></h5>
														<span class="fs-14 text-muted">Class VII-A</span>
													</div>
												</div>	
												<div class="icon-box st-box ms-auto">
													<a href="javascript:void(0);">
														<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"></path>
														</svg>
													</a>		
												</div>
											</div>
											<div class="d-flex justify-content-between mb-3 mt-3 pb-3 user border-bottom">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic1.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="app-profile.php">Tony Soap</a></h5>
														<span class="fs-14 text-muted">Class VII-A</span>
													</div>
												</div>	
												<div class="icon-box st-box ms-auto">
													<a href="javascript:void(0);">
														<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"></path>
														</svg>
													</a>		
												</div>
											</div>
											<div class="d-flex justify-content-between mb-3 mt-3 pb-3 user border-bottom">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic3.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="app-profile.php">Karen Hope</a></h5>
														<span class="fs-14 text-muted">Class VII-A</span>
													</div>
												</div>	
												<div class="icon-box st-box ms-auto">
													<a href="javascript:void(0);">
														<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"></path>
														</svg>
													</a>		
												</div>
											</div>
											<div class="d-flex justify-content-between mb-3 mt-3 pb-3 user border-bottom">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic2.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="app-profile.php">Jordan Nico</a></h5>
														<span class="fs-14 text-muted">Class VII-B</span>
													</div>
												</div>	
												<div class="icon-box st-box ms-auto">
													<a href="#">
														<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"></path>
														</svg>
													</a>		
												</div>
											</div>
											<div class="d-flex justify-content-between mb-3 mt-3 pb-3 user border-bottom">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic5.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="app-profile.php">Nadila Adja</a></h5>
														<span class="fs-14 text-muted">Class VII-C</span>
													</div>
												</div>	
												<div class="icon-box st-box ms-auto">
													<a href="#">
														<svg width="22" height="16" viewBox="0 0 22 16" fill="none" xmlns="http://www.w3.org/2000/svg">
														<path d="M19 0.000114441H3C2.20435 0.000114441 1.44129 0.316185 0.878679 0.878794C0.31607 1.4414 0 2.20446 0 3.00011V13.0001C0 13.7958 0.31607 14.5588 0.878679 15.1214C1.44129 15.684 2.20435 16.0001 3 16.0001H19C19.7956 16.0001 20.5587 15.684 21.1213 15.1214C21.6839 14.5588 22 13.7958 22 13.0001V3.00011C22 2.20446 21.6839 1.4414 21.1213 0.878794C20.5587 0.316185 19.7956 0.000114441 19 0.000114441V0.000114441ZM20 12.7501L15.1 8.35011L20 4.92011V12.7501ZM2 4.92011L6.9 8.35011L2 12.7501V4.92011ZM8.58 9.53011L10.43 10.8201C10.5974 10.9362 10.7963 10.9985 11 10.9985C11.2037 10.9985 11.4026 10.9362 11.57 10.8201L13.42 9.53011L18.42 14.0001H3.6L8.58 9.53011ZM3 2.00011H19C19.1857 2.0016 19.3673 2.05478 19.5245 2.15369C19.6817 2.2526 19.8083 2.39333 19.89 2.56011L11 8.78011L2.11 2.56011C2.19171 2.39333 2.31826 2.2526 2.47545 2.15369C2.63265 2.05478 2.81428 2.0016 3 2.00011V2.00011Z" fill="#A098AE"></path>
														</svg>
													</a>		
												</div>
											</div>
										</div>
									</div>
									<div class="card-footer border-0 pt-0">
										<div class="text-center border-0 pt-3">
											<a href="javascript:void(0);" class="btn btn-block btn-primary light btn-rounded dz-load-more" id="RecentActivity" rel="ajax/message.php">View More</a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xl-6 col-lg-6 col-md-12">
								<div class="card">
									<div class="card-header d-block border-0 pb-0 ">
										<div class="d-flex justify-content-between">
											<div>
												<h3 class="heading">Messages</h3>
												<span>You have <span class="font-w600">10 New</span> Messages</span>
											</div>
											<button type="button" class="icon-box icon-box-sm bg-primary border-0" data-bs-toggle="modal" data-bs-target="#exampleModal-1">
												 <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
												<path d="M5.87826 10.0611H0V5.869H5.87826V0H10.0522V5.869H16V10.0611H10.0522V16H5.87826V10.0611Z" fill="white"/>
												</svg>
											</button>
										</div>
										<div class="input-group user-search-area flex-nowrap">
										  <span class="input-group-text" id="addon-wrapping"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M23.6 21.8001L18 16.2001C19.3 14.5001 20.1 12.4001 20.1 10.1001C20.1 4.6001 15.6 0.100098 10.1 0.100098C4.6 0.100098 0 4.6001 0 10.1001C0 15.6001 4.5 20.1001 10 20.1001C12.3 20.1001 14.5 19.3001 16.2 17.9001L21.8 23.5001C22 23.7001 22.4 23.9001 22.7 23.9001C23 23.9001 23.3 23.8001 23.6 23.5001C24.1 23.1001 24.1 22.3001 23.6 21.8001ZM2.5 10.1001C2.5 6.0001 5.9 2.6001 10 2.6001C14.1 2.6001 17.5 6.0001 17.5 10.1001C17.5 14.2001 14.1 17.6001 10 17.6001C5.9 17.6001 2.5 14.3001 2.5 10.1001Z" fill="var(--primary)"/>
											</svg>
											</span>
										  <input type="text" class="form-control ps-0" placeholder="Search here..." aria-label="Username" aria-describedby="addon-wrapping">
										</div>
									</div>
									
									<div class="card-body height450 dz-scroll py-0">
										<div class="contacts-list" id="RecentMessagesContent">
											<div class="d-flex justify-content-between mb-3 mt-3 border-bottom pb-3">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic4.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="email-inbox.php">Samantha William</a></h5>
														<span class="fs-14 text-muted text-wrap">Lorem ipsum dolor sit amet...</span>
													</div>
												</div>	
												<div class="text-end">
													<span class="d-block mb-1">12:45 PM</span>
													<span class="badge badge-secondary rounded-circle">2</span>	
												</div>																				
											</div>
											<div class="d-flex justify-content-between mb-3 mt-3 border-bottom pb-3">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic1.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="email-inbox.php">Tony Soap</a></h5>
														<span class="fs-14 text-muted text-wrap">Lorem ipsum dolor sit amet...</span>
													</div>
												</div>	
												<div class="text-end">
													<span class="d-block mb-1">12:45 PM</span>
													<span class="badge badge-secondary rounded-circle">3</span>	
												</div>																				
											</div>
											<div class="d-flex justify-content-between mb-3 mt-3 border-bottom pb-3">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic2.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="email-inbox.php">Jordan Nico</a></h5>
														<span class="fs-14 text-muted text-wrap">Lorem ipsum dolor sit amet...</span>
													</div>
												</div>	
												<div class="text-end">
													<span class="d-block mb-1">12:45 PM</span>
												</div>																				
											</div>
											<div class="d-flex justify-content-between mb-3 mt-3 border-bottom pb-3">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic3.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="email-inbox.php">Karen Hope</a></h5>
														<span class="fs-14 text-muted text-wrap">Lorem ipsum dolor sit amet...</span>
													</div>
												</div>	
												<div class="text-end">
													<span class="d-block mb-1">12:45 PM</span>
													<span class="badge badge-secondary rounded-circle">4</span>	
												</div>																				
											</div>
											<div class="d-flex justify-content-between mb-3 mt-3 border-bottom pb-3">
												<div class="d-flex align-items-center">
													<img src="assets/images/profile/small/pic5.jpg" alt="" class="avatar">
													<div class="ms-3">
														<h5 class="mb-1"><a href="email-inbox.php">Nadila Adja</a></h5>
														<span class="fs-14 text-muted text-wrap">Lorem ipsum dolor sit amet...</span>
													</div>
												</div>	
												<div class="text-end">
													<span class="d-block mb-1">12:45 PM</span>	
												</div>																				
											</div>
										</div>
									</div>
									<div class="card-footer border-0 pt-0">
										<div class="text-center border-0 pt-3">
											<a href="javascript:void(0);" class="btn btn-block btn-primary light btn-rounded dz-load-more" id="RecentMessages" rel="ajax/contacts.php">View More</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-3">
						<div class="card bg-primary plan-bx h-auto">
							<div class="card-body">
								<ul class="d-flex align-items-baseline justify-content-between mb-3">
									<li class="plan-svg">
										<svg width="85" height="228" viewBox="0 0 85 228" fill="none" xmlns="http://www.w3.org/2000/svg">
										<rect width="100" height="294" rx="50" fill="#FCC43E"/>
										</svg>
									</li>
									<li class="plan-svg-1">
										<svg width="100" height="180" viewBox="0 0 100 180" fill="none" xmlns="http://www.w3.org/2000/svg">
											<rect width="100" height="294" rx="50" fill="#FB7D5B"/>
											</svg>

									</li>
									<li class="text-white">Your Plan<h3 class="text-white">Free</h3></li>
									<li><div class="dropdown custom-dropdown">
										<div class="btn sharp tp-btn " data-bs-toggle="dropdown">
											<svg width="24" height="6" viewBox="0 0 24 6" fill="none" xmlns="http://www.w3.org/2000/svg">
												<path d="M12.0012 0.359985C11.6543 0.359985 11.3109 0.428302 10.9904 0.561035C10.67 0.693767 10.3788 0.888317 10.1335 1.13358C9.88829 1.37883 9.69374 1.67 9.56101 1.99044C9.42828 2.31089 9.35996 2.65434 9.35996 3.00119C9.35996 3.34803 9.42828 3.69148 9.56101 4.01193C9.69374 4.33237 9.88829 4.62354 10.1335 4.8688C10.3788 5.11405 10.67 5.3086 10.9904 5.44134C11.3109 5.57407 11.6543 5.64239 12.0012 5.64239C12.7017 5.64223 13.3734 5.36381 13.8686 4.86837C14.3638 4.37294 14.6419 3.70108 14.6418 3.00059C14.6416 2.3001 14.3632 1.62836 13.8677 1.13315C13.3723 0.637942 12.7004 0.359826 12 0.359985H12.0012ZM3.60116 0.359985C3.25431 0.359985 2.91086 0.428302 2.59042 0.561035C2.26997 0.693767 1.97881 0.888317 1.73355 1.13358C1.48829 1.37883 1.29374 1.67 1.16101 1.99044C1.02828 2.31089 0.959961 2.65434 0.959961 3.00119C0.959961 3.34803 1.02828 3.69148 1.16101 4.01193C1.29374 4.33237 1.48829 4.62354 1.73355 4.8688C1.97881 5.11405 2.26997 5.3086 2.59042 5.44134C2.91086 5.57407 3.25431 5.64239 3.60116 5.64239C4.30165 5.64223 4.97339 5.36381 5.4686 4.86837C5.9638 4.37294 6.24192 3.70108 6.24176 3.00059C6.2416 2.3001 5.96318 1.62836 5.46775 1.13315C4.97231 0.637942 4.30045 0.359826 3.59996 0.359985H3.60116ZM20.4012 0.359985C20.0543 0.359985 19.7109 0.428302 19.3904 0.561035C19.07 0.693767 18.7788 0.888317 18.5336 1.13358C18.2883 1.37883 18.0937 1.67 17.961 1.99044C17.8283 2.31089 17.76 2.65434 17.76 3.00119C17.76 3.34803 17.8283 3.69148 17.961 4.01193C18.0937 4.33237 18.2883 4.62354 18.5336 4.8688C18.7788 5.11405 19.07 5.3086 19.3904 5.44134C19.7109 5.57407 20.0543 5.64239 20.4012 5.64239C21.1017 5.64223 21.7734 5.36381 22.2686 4.86837C22.7638 4.37294 23.0419 3.70108 23.0418 3.00059C23.0416 2.3001 22.7632 1.62836 22.2677 1.13315C21.7723 0.637942 21.1005 0.359826 20.4 0.359985H20.4012Z" fill="#fff"/>
											</svg>
										</div>
										<div class="dropdown-menu dropdown-menu-end">
											<a class="dropdown-item" href="javascript:void(0);">Option 1</a>
											<a class="dropdown-item" href="javascript:void(0);">Option 2</a>
											<a class="dropdown-item" href="javascript:void(0);">Option 3</a>
										</div>
									</div>
									</li>
								</ul>
								<ul class="food-recipe text-white">
									<li>
										<span class="text-white">50 GB Storage</span>
									</li>
									<li>
										<span class="text-white">Limited Features</span>
									</li>
								</ul>
								<p class="text-white w-75">Upgrade to Premium Plan to get more Features </p>
								
								<button class="btn btn-light btn-sm">Upgrade Plan</button>
							</div>
						</div>
						<div class="card h-auto">
							<div class="card-header border-0 pb-0">
								<h3 class="heading mb-0">Lastest Activity</h3>
							</div>
							<div class="card-body pt-0">
								<div class="dz-scroll">
									<ul class="timeline-active">
										<li class="d-flex timeline-list">
											<div class="dz-media">
												<img src="./assets/images/profile/14.jpg" alt="" class="avatar avatar-sm">
											</div>
											<div class="panel">
												<a class="timeline-panel text-muted d-flex align-items-center mb-0" href="#">
													<span><strong class="">Karen Hope</strong> moved task <strong class="text-secondary font-w500">“User Research“</strong>from On Progress to Done </span>
													
												</a>
												<span class="time py-0">Monday, June 31 2020</span>	
											</div>
										</li>
										<li class="d-flex timeline-list">
											<div class="dz-media">
												<img src="./assets/images/profile/18.jpg" alt="" class="avatar avatar-sm">
											</div>
											<div class="panel">
												<a class="timeline-panel text-muted d-flex align-items-center mb-0" href="#">
													<span><strong>Samantha William </strong>add new<strong class="text-primary"> 4 </strong>attached files on task<strong class="text-warning fonr-w500">“Photo’s Assets“</strong></span>
													 
												</a>
												<span class="time py-0">Monday, June 31 2020</span>	
												
											</div>
										</li>
										<li class="d-flex timeline-list">
											<div class="dz-media">
												<img src="./assets/images/profile/19.jpg" alt="" class="avatar avatar-sm">
											</div>
											<div class="panel">
												<a class="timeline-panel text-muted d-flex align-items-center mb-0" href="#">
													<span class="mb-0" ><strong>Samantha William </strong> add 4 files on  Frize <strong class="text-danger font-w500">Projects </strong></span>
												</a>
												<span class="time py-0">Monday, June 31 2020</span>	
											</div>
											
										</li>
										<li class="d-flex pb-0">
											<div class="dz-media">
												<img src="./assets/images/profile/18.jpg" alt="" class="avatar avatar-sm">
											</div>
											<div class="panel">
												<a class="timeline-panel text-muted d-flex align-items-center mb-0" href="#">
													<span class="mb-0" ><strong>Samantha William </strong> Created new <strong class="text-danger font-w500">Task</strong></span>
												</a>
												<span class="time py-0">Monday, June 31 2020</span>	
											</div>
											
										</li>
									</ul>
								</div>	
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--**********************************
					moal
				***********************************-->
		
		
        <!--**********************************
            Content body end
        ***********************************-->
		
			

			<!-- Modal -->
			<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog modal-dialog-center ">
				<div class="modal-content">
				  <div class="modal-header">
					<h1 class="modal-title fs-5" id="exampleModalLabel">New Contact</h1>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				  </div>
				  <div class="modal-body">
						<div class="row">
							<div class="col-xl-6">
								<div class="mb-3">
								  <label for="exampleFormControlInput1" class="form-label">Fisrt Name</label>
								  <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Samanta">
								</div>
								<div class="mb-3">
								  <label for="exampleFormControlInput2" class="form-label">Company</label>
								  <input type="text" class="form-control" id="exampleFormControlInput2" placeholder="Company">
								</div>
								<div class="mb-3">
								  <label for="exampleFormControlInput3" class="form-label">Mobile Number</label>
								  <input type="number" class="form-control" id="exampleFormControlInput3" placeholder="+123456789">
								</div>
							</div>
							<div class="col-xl-6">
								<div class="mb-3">
								  <label for="exampleFormControlInput6" class="form-label">Fisrt Name</label>
								  <input type="text" class="form-control" id="exampleFormControlInput6" placeholder="William">
								</div>
								<div class="mb-3">
								  <label for="exampleFormControlInput4" class="form-label">Email Id</label>
								  <input type="email" class="form-control" id="exampleFormControlInput4" placeholder="hello@gmail.com">
								</div>
								<div class="mb-3">
								  <label for="exampleFormControlInput5" class="form-label">Job Title</label>
								  <input type="text" class="form-control" id="exampleFormControlInput5" placeholder="Title">
								</div>
								
							</div>
						</div>
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				  </div>
				</div>
			  </div>
			</div>
			<!-- Modal -->
			<div class="modal fade" id="exampleModal-1" tabindex="-1" aria-labelledby="exampleModalLabel-1" aria-hidden="true">
			  <div class="modal-dialog modal-dialog-center ">
				<div class="modal-content">
				  <div class="modal-header">
					<h1 class="modal-title fs-5" id="exampleModalLabel-1">New Message</h1>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				  </div>
				  <div class="modal-body">
						<div class="row">
							<div class="col-xl-6">
								<div class="mb-3">
								  <label for="exampleFormControlInput7" class="form-label">Fisrt Name</label>
								  <input type="text" class="form-control" id="exampleFormControlInput7" placeholder="Samanta">
								</div>
								
							</div>
							<div class="col-xl-6">
								<div class="mb-3">
								  <label for="exampleFormControlInput8" class="form-label">Last Name</label>
								  <input type="text" class="form-control" id="exampleFormControlInput8" placeholder="William">
								</div>
							</div>
						</div>
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-danger light" data-bs-dismiss="modal">Close</button>
					<button type="button" class="btn btn-primary">Save changes</button>
				  </div>
				</div>
			  </div>
			</div>


		<!--**********************************
           Support ticket button start
        ***********************************-->
		
        <!--**********************************
           Support ticket button end
        ***********************************-->
		
		<!-- footer-start -->
		
			<?php include 'elements/footer.php'; ?>
				
			<!-- footer-end -->


	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

<!--**********************************
	Modal
***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <?php include 'elements/page-js.php'; ?>
	

</body>
</html>