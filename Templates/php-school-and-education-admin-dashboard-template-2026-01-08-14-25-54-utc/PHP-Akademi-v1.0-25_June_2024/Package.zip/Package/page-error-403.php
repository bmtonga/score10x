<?php 
	 require_once __DIR__ . '/config/dz.php';
?>
<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
		<!-- PAGE TITLE HERE -->
		 <title><?php echo $DexignZoneSettings['site_level']['site_title'] ?></title>
		 <?php include 'elements/meta.php';?>
		 <!-- FAVICONS ICON -->
		 <link rel="shortcut icon" type="image/png" href="<?php echo $DexignZoneSettings['site_level']['favicon']?>">
		 
		 <?php include 'elements/page-css.php'; ?>
	 </head>

<body class="vh-100">
    <div class="authincation h-100" style="background-image: url(assets/images/student-bg.jpg); background-repeat:no-repeat; background-size:cover;">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-lg-6 col-sm-12">
                    <div class="form-input-content  error-page">
						<h1 class="error-text text-primary">403</h1>
						<h4> Forbidden Error!</h4>
						<p>You do not have permission to view this resource.</p>
                        <a class="btn btn-primary" href="index.php">Back to Home</a>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-12">
					<img  class="w-100" src="assets/images/svg/student.svg" alt="">
				</div>
            </div>
        </div>
    </div>

<!--**********************************
	Scripts
***********************************-->
<!-- Required vendors -->
<?php include 'elements/page-js.php'; ?>
</body>
</html>