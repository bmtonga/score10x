<?php 
	 require_once __DIR__ . '/config/dz.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<!-- PAGE TITLE HERE -->
	<title><?php echo $DexignZoneSettings['site_level']['site_title'] ?></title>
	<?php include 'elements/meta.php'; ?>
	<!-- FAVICONS ICON -->
	<link rel="shortcut icon" type="image/png" href="<?php echo $DexignZoneSettings['site_level']['favicon'] ?>">

	<?php include 'elements/page-css.php'; ?>
</head>

<body>

	<!--*******************
        Preloader start
    ********************-->

	<?php include 'elements/pre-loader.php'; ?>
	<!--*******************
        Preloader end
    ********************-->


	<!--**********************************
        Main wrapper start
    ***********************************-->
	<div id="main-wrapper">

		<!--**********************************
            Nav header start
        ***********************************-->
		<?php include 'elements/nav-header.php'; ?>
		<!--**********************************
            Nav header end
        ***********************************-->

		<!--**********************************
            Chat box start
        ***********************************-->
		<?php include 'elements/chatbox.php'; ?>
		<!--**********************************
            Chat box End
        ***********************************-->




		<!--**********************************
            Header start
        ***********************************-->
		<?php include 'elements/header.php'; ?>

		<!--**********************************
            Header end ti-comment-alt
        ***********************************-->

		<!--**********************************
            Sidebar start
        ***********************************-->
		<?php include 'elements/sidebar.php'; ?>
		<!--**********************************
            Sidebar end
        ***********************************-->

		<!--**********************************
            Content body start
        ***********************************-->
		<div class="content-body">
			<div class="container-fluid">
				<!-- row -->
				<div class="row">
					<div class="col-lg-12">
						<div class="profile card card-body px-3 pt-3 pb-0">
							<div class="profile-head">
								<div class="photo-content">
									<div class="cover-photo rounded"></div>
								</div>
								<div class="profile-info">
									<div class="profile-photo">
										<img src="assets/images/profile/profile.png" class="img-fluid rounded-circle" alt="">
									</div>
									<div class="profile-details">
										<div class="profile-name px-3 pt-2">
											<h4 class="text-primary mb-0">Mitchell C. Shay</h4>
											<p>UX / UI Designer</p>
										</div>
										<div class="profile-email px-2 pt-2">
											<h4 class="text-muted mb-0">hello@email.com</h4>
											<p>Email</p>
										</div>
										<div class="dropdown ms-auto">
											<a href="#" class="btn btn-primary light sharp" data-bs-toggle="dropdown" aria-expanded="true"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18px" height="18px" viewBox="0 0 24 24" version="1.1">
													<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
														<rect x="0" y="0" width="24" height="24"></rect>
														<circle fill="#000000" cx="12" cy="5" r="2"></circle>
														<circle fill="#000000" cx="12" cy="12" r="2"></circle>
														<circle fill="#000000" cx="12" cy="19" r="2"></circle>
													</g>
												</svg></a>
											<ul class="dropdown-menu dropdown-menu-end">
												<li class="dropdown-item"><i class="fa fa-user-circle text-primary me-2"></i> View profile</li>
												<li class="dropdown-item"><i class="fa fa-users text-primary me-2"></i> Add to btn-close friends</li>
												<li class="dropdown-item"><i class="fa fa-plus text-primary me-2"></i> Add to group</li>
												<li class="dropdown-item"><i class="fa fa-ban text-primary me-2"></i> Block</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xl-4">
						<div class="row">
							<div class="col-xl-12">
								<div class="card">
									<div class="card-body">
										<div class="profile-statistics">
											<div class="text-center">
												<div class="row">
													<div class="col">
														<h3 class="m-b-0">150</h3><span>Follower</span>
													</div>
													<div class="col">
														<h3 class="m-b-0">140</h3><span>Place Stay</span>
													</div>
													<div class="col">
														<h3 class="m-b-0">45</h3><span>Reviews</span>
													</div>
												</div>
												<div class="mt-4">
													<a href="javascript:void(0);;;" class="btn btn-primary mb-1 me-1">Follow</a>
													<a href="javascript:void(0);;;" class="btn btn-primary mb-1" data-bs-toggle="modal" data-bs-target="#sendMessageModal">Send Message</a>
												</div>
											</div>
											<!-- Modal -->
											<div class="modal fade" id="sendMessageModal">
												<div class="modal-dialog modal-dialog-centered" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title">Send Message</h5>
															<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
														</div>
														<div class="modal-body">
															<form class="comment-form">
																<div class="row">
																	<div class="col-lg-6">
																		<div class="mb-3">
																			<label class="text-black font-w600 form-label">Name <span class="required">*</span></label>
																			<input type="text" class="form-control" value="Author" name="Author" placeholder="Author">
																		</div>
																	</div>
																	<div class="col-lg-6">
																		<div class="mb-3">
																			<label class="text-black font-w600 form-label">Email <span class="required">*</span></label>
																			<input type="text" class="form-control" value="Email" placeholder="Email" name="Email">
																		</div>
																	</div>
																	<div class="col-lg-12">
																		<div class="mb-3">
																			<label class="text-black font-w600 form-label">Comment</label>
																			<textarea rows="4" class="form-control" name="comment" placeholder="Comment"></textarea>
																		</div>
																	</div>
																	<div class="col-lg-12">
																		<div class="mb-3 mb-0">
																			<input type="submit" value="Post Comment" class="submit btn btn-primary" name="submit">
																		</div>
																	</div>
																</div>
															</form>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xl-12">
								<div class="card">
									<div class="card-body">
										<div class="profile-blog">
											<h5 class="text-primary d-inline">Today Highlights</h5>
											<img src="assets/images/profile/1.jpg" alt="" class="img-fluid mt-4 mb-4 w-100 rounded">
											<h4><a href="post-details.php" class="text-black">Proof That EDUCATION Is Exactly What You Are Looking For</a></h4>
											<p class="mb-0">For developing a nation, it is important to provide education to each one of living in the society. The key to a developed nation is connected with the education.</p>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xl-12">
								<div class="card">
									<div class="card-body">
										<div class="profile-interest">
											<h5 class="text-primary d-inline">Interest</h5>
											<div class="row mt-4 sp4" id="lightgallery">
												<a href="assets/images/profile/2.jpg" data-exthumbimage="assets/images/profile/2.jpg" data-src="assets/images/profile/2.jpg" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
													<img src="assets/images/profile/2.jpg" alt="" class="img-fluid rounded">
												</a>
												<a href="assets/images/profile/3.jpg" data-exthumbimage="assets/images/profile/3.jpg" data-src="assets/images/profile/3.jpg" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
													<img src="assets/images/profile/3.jpg" alt="" class="img-fluid rounded">
												</a>
												<a href="assets/images/profile/4.jpg" data-exthumbimage="assets/images/profile/4.jpg" data-src="assets/images/profile/4.jpg" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
													<img src="assets/images/profile/4.jpg" alt="" class="img-fluid rounded">
												</a>
												<a href="assets/images/profile/3.jpg" data-exthumbimage="assets/images/profile/3.jpg" data-src="assets/images/profile/3.jpg" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
													<img src="assets/images/profile/3.jpg" alt="" class="img-fluid rounded">
												</a>
												<a href="assets/images/profile/4.jpg" data-exthumbimage="assets/images/profile/4.jpg" data-src="assets/images/profile/4.jpg" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
													<img src="assets/images/profile/4.jpg" alt="" class="img-fluid rounded">
												</a>
												<a href="assets/images/profile/2.jpg" data-exthumbimage="assets/images/profile/2.jpg" data-src="assets/images/profile/2.jpg" class="mb-1 col-lg-4 col-xl-4 col-sm-4 col-6">
													<img src="assets/images/profile/2.jpg" alt="" class="img-fluid rounded">
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xl-12">
								<div class="card">
									<div class="card-body">
										<div class="profile-news">
											<h5 class="text-primary d-inline">Our Latest News</h5>
											<div class="media pt-3 pb-3">
												<img src="assets/images/profile/5.jpg" alt="image" class="me-3 rounded" width="75">
												<div class="media-body">
													<h5 class="m-b-5"><a href="post-details.php" class="text-black">These Mistakes Will Destroy Your EDUCATION</a></h5>
													<p class="mb-0">Educational Institutions are established for availing education to student.</p>
												</div>
											</div>
											<div class="media pt-3 pb-3">
												<img src="assets/images/profile/6.jpg" alt="image" class="me-3 rounded" width="75">
												<div class="media-body">
													<h5 class="m-b-5"><a href="post-details.php" class="text-black">Best 50 Tips For EDUCATION</a></h5>
													<p class="mb-0">education is also suffering from class conflict.</p>
												</div>
											</div>
											<div class="media pt-3 pb-3">
												<img src="assets/images/profile/7.jpg" alt="image" class="me-3 rounded" width="75">
												<div class="media-body">
													<h5 class="m-b-5"><a href="post-details.php" class="text-black">EDUCATION: This Is What Professionals</a></h5>
													<p class="mb-0">system is degrading day by day due to various social and financial reasons.</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-8">
						<div class="card">
							<div class="card-body">
								<div class="post-details">
									<h3 class="mb-2 text-black">How To Get (A) Fabulous EDUCATION On A Tight Budget</h3>
									<ul class="mb-4 post-meta d-flex flex-wrap">
										<li class="post-author me-3">By Admin</li>
										<li class="post-date me-3"><i class="far fa-calendar-plus me-2"></i>18 Nov 2020</li>
										<li class="post-comment"><i class="far fa-comment me-2"></i>28</li>
									</ul>
									<img src="assets/images/profile/8.jpg" alt="" class="img-fluid mb-3 w-100 rounded">
									<p>A wonderful serenity has take possession of my entire soul like these sweet morning of spare which enjoy whole heart.A wonderful serenity has take possession of my entire soul like these sweet morning of spare which enjoy whole heart.</p>
									<p>A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame.</p>
									<blockquote>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Has been the industry's standard text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimencenturies.</blockquote>
									<p>A wonderful serenity has taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole heart. I am alone, and feel the charm of existence was created for the bliss of souls like mine.I am so happy, my dear friend, so absorbed in the exquisite sense of mere tranquil existence, that I neglect my talents.</p>
									<div class="profile-skills mt-5 mb-5">
										<h4 class="text-primary mb-2">Skills</h4>
										<a href="javascript:void(0);;;" class="btn btn-primary light btn-xs mb-1">Culture</a>
										<a href="javascript:void(0);;;" class="btn btn-primary light btn-xs mb-1">Programming</a>
										<a href="javascript:void(0);;;" class="btn btn-primary light btn-xs mb-1">Art</a>
										<a href="javascript:void(0);;;" class="btn btn-primary light btn-xs mb-1">English</a>
										<a href="javascript:void(0);;;" class="btn btn-primary light btn-xs mb-1">Maths</a>
										<a href="javascript:void(0);;;" class="btn btn-primary light btn-xs mb-1">Histroy</a>
									</div>
									<div class="comment-respond" id="respond">
										<h4 class="comment-reply-title text-primary mb-3" id="reply-title">Leave a Reply </h4>
										<form class="comment-form" id="commentform" method="post">
											<div class="row">
												<div class="col-lg-6">
													<div class="mb-3">
														<label for="author" class="text-black font-w600 form-label">Name <span class="required">*</span></label>
														<input type="text" class="form-control" value="Author" name="Author" placeholder="Author" id="author">
													</div>
												</div>
												<div class="col-lg-6">
													<div class="mb-3">
														<label for="email" class="text-black font-w600 form-label">Email <span class="required">*</span></label>
														<input type="text" class="form-control" value="Email" placeholder="Email" name="Email" id="email">
													</div>
												</div>
												<div class="col-lg-12">
													<div class="mb-3">
														<label for="comment" class="text-black font-w600 form-label">Comment</label>
														<textarea rows="5" class="form-control" name="comment" placeholder="Comment" id="comment"></textarea>
													</div>
												</div>
												<div class="col-lg-12">
													<div class="mb-3">
														<input type="submit" value="Post Comment" class="submit btn btn-primary" id="submit" name="submit">
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--**********************************
            Content body end
        ***********************************-->

		<!--**********************************
			Footer start
		***********************************-->
		<?php include 'elements/footer.php'; ?>
		<!--**********************************
			Footer end
		***********************************-->
		<!--**********************************
           Support ticket button start
        ***********************************-->

		<!--**********************************
           Support ticket button end
        ***********************************-->


	</div>
	<!--**********************************
        Main wrapper end
    ***********************************-->

	<!--removeIf(production)-->

	<!--**********************************
        Scripts
    ***********************************-->
	<!-- Required vendors -->
	<?php include 'elements/page-js.php'; ?>
	<script>
		$('#lightgallery').lightGallery({
			thumbnail: true,
		});
	</script>

</body>

</html>