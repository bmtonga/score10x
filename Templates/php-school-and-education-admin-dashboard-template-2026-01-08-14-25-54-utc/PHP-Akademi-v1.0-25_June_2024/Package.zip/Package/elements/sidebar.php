<div class="dlabnav">
    <div class="dlabnav-scroll">
        <ul class="metismenu" id="menu">
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-symbols-outlined">home</i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="index.php">Dashboard Light</a></li>
                    <li><a href="index-2.php">Dashboard Dark</a></li>
                    <li><a href="finance.php">Finance</a></li>
                </ul>

            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-symbols-outlined">school</i>
                    <span class="nav-text">Student</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="student.php">Student</a></li>
                    <li><a href="student-detail.php">Student Detail</a></li>
                    <li><a href="add-student.php">Add New Student</a></li>

                </ul>

            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-symbols-outlined">person</i>
                    <span class="nav-text">Teacher</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="teacher.php">Teacher</a></li>
                    <li><a href="teacher-detail.php">Teacher Detail</a></li>
                    <li><a href="add-teacher.php">Add New Teacher</a></li>

                </ul>

            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-symbols-outlined">restaurant_menu</i>
                    <span class="nav-text">Food</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="food.php">Food menu</a></li>
                    <li><a href="food-details.php">Food Detail</a></li>
                </ul>

            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-icons">folder</i>
                    <span class="nav-text">File Manager</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="file-manager.php">File Manager</a></li>
                    <li><a href="user.php">User</a></li>
                    <li><a href="celandar.php">Calendar</a></li>
                    <li><a href="chat.php">Chat</a></li>
                    <li><a href="activity.php">Activity</a></li>
                </ul>
            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-icons"> app_registration </i>
                    <span class="nav-text">Apps</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="app-profile.php">Profile</a></li>
                    <li><a href="edit-profile.php">Edit Profile</a></li>
                    <li><a href="post-details.php">Post Details</a></li>
                    <li><a class="has-arrow" href="javascript:void(0);" aria-expanded="false">Email</a>
                        <ul aria-expanded="false">
                            <li><a href="email-compose.php">Compose</a></li>
                            <li><a href="email-inbox.php">Inbox</a></li>
                            <li><a href="email-read.php">Read</a></li>
                        </ul>
                    </li>
                    <li><a href="app-calender.php">Calendar</a></li>
                    <li><a class="has-arrow" href="javascript:void(0);" aria-expanded="false">Shop</a>
                        <ul aria-expanded="false">
                            <li><a href="ecom-product-grid.php">Product Grid</a></li>
                            <li><a href="ecom-product-list.php">Product List</a></li>
                            <li><a href="ecom-product-detail.php">Product Details</a></li>
                            <li><a href="ecom-product-order.php">Order</a></li>
                            <li><a href="ecom-checkout.php">Checkout</a></li>
                            <li><a href="ecom-invoice.php">Invoice</a></li>
                            <li><a href="ecom-customers.php">Customers</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-icons"> assessment </i>
                    <span class="nav-text">Charts</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="chart-flot.php">Flot</a></li>
                    <li><a href="chart-morris.php">Morris</a></li>
                    <li><a href="chart-chartjs.php">Chartjs</a></li>
                    <li><a href="chart-chartist.php">Chartist</a></li>
                    <li><a href="chart-sparkline.php">Sparkline</a></li>
                    <li><a href="chart-peity.php">Peity</a></li>
                </ul>
            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">

                    <i class="material-icons"> favorite </i>
                    <span class="nav-text">Bootstrap</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="ui-accordion.php">Accordion</a></li>
                    <li><a href="ui-alert.php">Alert</a></li>
                    <li><a href="ui-badge.php">Badge</a></li>
                    <li><a href="ui-button.php">Button</a></li>
                    <li><a href="ui-modal.php">Modal</a></li>
                    <li><a href="ui-button-group.php">Button Group</a></li>
                    <li><a href="ui-list-group.php">List Group</a></li>
                    <li><a href="ui-card.php">Cards</a></li>
                    <li><a href="ui-carousel.php">Carousel</a></li>
                    <li><a href="ui-dropdown.php">Dropdown</a></li>
                    <li><a href="ui-popover.php">Popover</a></li>
                    <li><a href="ui-progressbar.php">Progressbar</a></li>
                    <li><a href="ui-tab.php">Tab</a></li>
                    <li><a href="ui-typography.php">Typography</a></li>
                    <li><a href="ui-pagination.php">Pagination</a></li>
                    <li><a href="ui-grid.php">Grid</a></li>

                </ul>
            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-icons"> extension </i>
                    <span class="nav-text">Plugins</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="uc-select2.php">Select 2</a></li>
                    <li><a href="uc-nestable.php">Nestedable</a></li>
                    <li><a href="uc-noui-slider.php">Noui Slider</a></li>
                    <li><a href="uc-sweetalert.php">Sweet Alert</a></li>
                    <li><a href="uc-toastr.php">Toastr</a></li>
                    <li><a href="map-jqvmap.php">Jqv Map</a></li>
                    <li><a href="uc-lightgallery.php">Light Gallery</a></li>
                </ul>
            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-icons"> widgets </i>
                    <span class="nav-text">Widget</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="widget-chart.php">Chart</a></li>
                    <li><a href="widget-card.php">Card</a></li>
                    <li><a href="widget-list.php">List</a></li>
                </ul>
            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-icons"> insert_drive_file </i>
                    <span class="nav-text">Forms</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="form-element.php">Form Elements</a></li>
                    <li><a href="form-wizard.php">Wizard</a></li>
                    <li><a href="form-ckeditor.php">CkEditor</a></li>
                    <li><a href="form-pickers.php">Pickers</a></li>
                    <li><a href="form-validation.php">Form Validate</a></li>
                </ul>
            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-icons"> table_chart </i>
                    <span class="nav-text">Table</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="table-bootstrap-basic.php">Bootstrap</a></li>
                    <li><a href="table-datatable-basic.php">Datatable</a></li>
                </ul>
            </li>
            <li><a class="has-arrow " href="javascript:void(0);" aria-expanded="false">
                    <i class="material-icons">article</i>
                    <span class="nav-text">Pages</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="page-login.php">Login</a></li>
                    <li><a href="page-register.php">Register</a></li>
                    <li><a class="has-arrow" href="javascript:void(0);" aria-expanded="false">Error</a>
                        <ul aria-expanded="false">
                            <li><a href="page-error-400.php">Error 400</a></li>
                            <li><a href="page-error-403.php">Error 403</a></li>
                            <li><a href="page-error-404.php">Error 404</a></li>
                            <li><a href="page-error-500.php">Error 500</a></li>
                            <li><a href="page-error-503.php">Error 503</a></li>
                        </ul>
                    </li>
                    <li><a href="page-lock-screen.php">Lock Screen</a></li>
                    <li><a href="empty-page.php">Empty Page</a></li>
                </ul>
            </li>
        </ul>
        <div class="copyright">
            <p><strong>PHP School Admission Dashboard</strong></p>
            <p class="fs-12">Made with <span class="heart"></span> by DexignLab</p>
        </div>
    </div>
</div>