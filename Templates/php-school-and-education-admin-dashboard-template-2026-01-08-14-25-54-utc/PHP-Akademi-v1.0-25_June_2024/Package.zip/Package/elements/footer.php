<?php 
if($CurrentPage == "index" || $CurrentPage == "index-2" ){
    $footerClass = 'footer-outer';
}else{
    $footerClass = 'out-footer style-2';
}

?>
<div class="footer <?php echo $footerClass; ?>">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2024</p>
    </div>
</div>